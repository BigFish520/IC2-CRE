package ic2cre.api.event;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.Event;

/** 允许外部宿主应用拟态面的公共扩展点。 / Public extension point for non-IC2 obscuration hosts. */
public final class ObscurationApplyEvent extends Event {
    private final Level level;
    private final BlockPos pos;
    private final Direction targetSide;
    private final Player player;
    private final BlockState sourceState;
    private final Direction sourceSide;
    private final CompoundTag renderSnapshot;
    private boolean applied;

    public ObscurationApplyEvent(Level level, BlockPos pos, Direction targetSide, Player player,
                                 BlockState sourceState, Direction sourceSide, CompoundTag renderSnapshot,
                                 boolean applied) {
        this.level = level;
        this.pos = pos.immutable();
        this.targetSide = targetSide;
        this.player = player;
        this.sourceState = sourceState;
        this.sourceSide = sourceSide;
        this.renderSnapshot = renderSnapshot.copy();
        this.applied = applied;
    }

    public Level getLevel() { return level; }
    public BlockPos getPos() { return pos; }
    public Direction getTargetSide() { return targetSide; }
    public Player getPlayer() { return player; }
    public BlockState getSourceState() { return sourceState; }
    public Direction getSourceSide() { return sourceSide; }
    public CompoundTag getRenderSnapshot() { return renderSnapshot.copy(); }
    public boolean isApplied() { return applied; }
    public void markApplied() { this.applied = true; }
}
