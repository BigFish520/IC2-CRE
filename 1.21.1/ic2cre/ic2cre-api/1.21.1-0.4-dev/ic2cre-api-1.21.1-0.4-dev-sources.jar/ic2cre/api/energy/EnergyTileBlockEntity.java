package ic2cre.api.energy;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** 负责能源网络注册生命周期的方块实体基类。 / Block-entity base owning its EnergyNet registration lifecycle. */
public abstract class EnergyTileBlockEntity extends BlockEntity
        implements IEnergyTile, IEnergyContainerProvider {
    private boolean registeredWithEnergyNet;

    protected EnergyTileBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Override public abstract IEnergyContainer getEnergyContainer();

    @Override
    public boolean isEnergyTileValid(net.minecraft.world.level.Level level, BlockPos pos) {
        return !isRemoved() && getLevel() == level && worldPosition.equals(pos)
                && level.getBlockEntity(pos) == this;
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && !level.isClientSide && !registeredWithEnergyNet
                && (this instanceof IEnergySource || this instanceof IEnergySink
                || this instanceof IEnergyConductor)) {
            EnergyNet.getInstance().addTile(level, this, worldPosition);
            registeredWithEnergyNet = true;
        }
    }

    @Override
    public void onChunkUnloaded() {
        unregisterFromEnergyNet();
        super.onChunkUnloaded();
    }

    @Override
    public void setRemoved() {
        unregisterFromEnergyNet();
        super.setRemoved();
    }

    protected final void unregisterFromEnergyNet() {
        if (!registeredWithEnergyNet) return;
        registeredWithEnergyNet = false;
        IEnergyNet energyNet = EnergyNet.getIfPresent();
        if (energyNet == null) return;
        energyNet.removeTile(this);
    }
}
