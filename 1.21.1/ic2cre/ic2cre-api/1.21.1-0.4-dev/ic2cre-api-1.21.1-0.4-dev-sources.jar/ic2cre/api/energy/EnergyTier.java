package ic2cre.api.energy;

/** 以 mEU/t 表示的 IC2 电压等级。 / IC2 voltage tiers represented in mEU/t. */
public enum EnergyTier {
    LV(1, EnergyUnits.ofEu(32L)),
    MV(2, EnergyUnits.ofEu(128L)),
    HV(3, EnergyUnits.ofEu(512L)),
    EV(4, EnergyUnits.ofEu(2_048L)),
    IV(5, EnergyUnits.ofEu(8_192L)),
    TIER_6(6, EnergyUnits.ofEu(32_768L)),
    TIER_7(7, EnergyUnits.ofEu(131_072L)),
    TIER_8(8, EnergyUnits.ofEu(524_288L)),
    TIER_9(9, EnergyUnits.ofEu(2_097_152L)),
    TIER_10(10, EnergyUnits.ofEu(8_388_608L)),
    TIER_11(11, EnergyUnits.ofEu(33_554_432L)),
    TIER_12(12, EnergyUnits.ofEu(134_217_728L)),
    TIER_13(13, EnergyUnits.ofEu(536_870_912L)),
    TIER_14(14, EnergyUnits.ofEu(2_147_483_648L)),
    TIER_15(15, EnergyUnits.ofEu(8_589_934_592L)),
    TIER_16(16, EnergyUnits.ofEu(34_359_738_368L));

    public final int level;
    public final long maxEuPerTick;
    public static final int MAX_LEVEL = 16;

    // 既有机器声明使用的可读名称。 / Readable names used by existing machine declarations.
    public static final EnergyTier LOW = LV;
    public static final EnergyTier MEDIUM = MV;
    public static final EnergyTier HIGH = HV;
    public static final EnergyTier EXTREME = EV;
    public static final EnergyTier INSANE = IV;

    EnergyTier(int level, long maxEuPerTick) {
        this.level = level;
        this.maxEuPerTick = maxEuPerTick;
    }

    public static EnergyTier fromLevel(int level) {
        if (level <= 1) return LV;
        if (level >= values().length) return TIER_16;
        return values()[level - 1];
    }

    public static int getTierLevelFromPower(long power) {
        if (power <= 0) return 0;
        int tier = 0;
        long threshold = EnergyUnits.ofEu(8L);
        while (power > threshold && tier < MAX_LEVEL) {
            threshold = EnergyUnits.saturatingMultiply(threshold, 4L);
            tier++;
            if (threshold == Long.MAX_VALUE) break;
        }
        return tier;
    }

    /** 将 IC2 公式 8 × 4^tier EU 转换为 mEU。 / Converts the IC2 formula 8 × 4^tier EU to mEU. */
    public static long getPowerFromTier(int tier) {
        if (tier < 0) return 0L;
        if (tier >= MAX_LEVEL) return TIER_16.maxEuPerTick;
        long power = EnergyUnits.ofEu(8L);
        for (int i = 0; i < tier; i++) {
            power = EnergyUnits.saturatingMultiply(power, 4L);
        }
        return power;
    }
}
