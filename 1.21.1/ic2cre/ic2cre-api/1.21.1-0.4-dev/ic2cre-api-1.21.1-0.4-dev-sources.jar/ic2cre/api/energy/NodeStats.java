package ic2cre.api.energy;

/** 能源节点最近一次统计周期的 mEU 数据。 / mEU statistics for an energy tile's latest sampling period. */
public record NodeStats(long energyIn, long energyOut, long voltage) {
    public NodeStats {
        energyIn = Math.max(0L, energyIn);
        energyOut = Math.max(0L, energyOut);
        voltage = Math.max(0L, voltage);
    }

    public int voltageTier() {
        return EnergyTier.getTierLevelFromPower(voltage);
    }
}
