package ic2cre.api.energy;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.Direction;
import net.neoforged.neoforge.capabilities.BlockCapability;

/** 能源网络机器与线缆公开的边界能力。 / Boundary capability exposed by EnergyNet machines and cables. */
public final class EnergyNetCapabilities {
    public static final BlockCapability<IExternalEnergyPort, Direction> EXTERNAL_ENERGY_PORT =
            BlockCapability.createSided(Ic2CreAPI.resource("external_energy_port"), IExternalEnergyPort.class);

    private EnergyNetCapabilities() {}
}
