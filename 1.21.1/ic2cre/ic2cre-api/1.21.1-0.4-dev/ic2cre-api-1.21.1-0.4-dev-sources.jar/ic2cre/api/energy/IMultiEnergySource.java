package ic2cre.api.energy;

/** 每 tick 可发送多个能源包的可选源契约。 / Optional source contract for emitting multiple packets per tick. */
public interface IMultiEnergySource extends IEnergySource {

    boolean sendMultipleEnergyPackets();

    int getMultipleEnergyPacketAmount();
}
