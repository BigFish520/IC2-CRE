package ic2cre.api.energy;

import net.minecraft.core.Direction;
import net.minecraft.world.item.DyeColor;

/** 按连接面提供线缆颜色的能源节点。 / Energy node that provides a cable color per connection face. */
public interface IColoredEnergyTile extends IEnergyTile {
    DyeColor getColor(Direction side);
}
