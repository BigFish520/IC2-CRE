package ic2cre.api.energy;

/**
 * 能源网络边界唯一的单位换算入口。 / Sole conversion authority at the EnergyNet boundary.
 *
 * <p>换算比例为 1 EU = 2 AE = 4 RF = 10 J = 4 FE；内部始终使用 mEU。
 * / Ratios are 1 EU = 2 AE = 4 RF = 10 J = 4 FE; internal values always use mEU.</p>
 */
public final class EnergyNetConversion {
    private EnergyNetConversion() {}

    public static long toInternal(ExternalEnergyUnit unit, long amount) {
        if (unit == null || amount <= 0L) return 0L;
        return EnergyUnits.saturatingMultiply(amount, milliEuPerUnit(unit));
    }

    public static long fromInternal(ExternalEnergyUnit unit, long milliEu) {
        if (unit == null || milliEu <= 0L) return 0L;
        return milliEu / milliEuPerUnit(unit);
    }

    public static long milliEuPerUnit(ExternalEnergyUnit unit) {
        return switch (unit) {
            case EU -> 1_000L;
            case AE -> 500L;
            case RF, FE -> 250L;
            case J -> 100L;
        };
    }
}
