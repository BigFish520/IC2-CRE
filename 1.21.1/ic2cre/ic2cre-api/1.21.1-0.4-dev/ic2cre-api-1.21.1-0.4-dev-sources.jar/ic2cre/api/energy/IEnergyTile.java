package ic2cre.api.energy;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/** 参与 IC2CRE 能源网络的节点及生命周期契约。 / Tile and lifecycle contract for participating in IC2CRE EnergyNet. */
public interface IEnergyTile {

    default void onConnectionChange() {
    }

    /** 用于移除失效图节点的防御性生命周期检查。 / Defensive lifecycle check used to prune stale graph nodes. */
    default boolean isEnergyTileValid(Level level, BlockPos pos) {
        return true;
    }
}
