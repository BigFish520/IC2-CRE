package ic2cre.api.energy;

import net.neoforged.neoforge.energy.IEnergyStorage;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/** 防御不规范外部能源能力的唯一调用边界。 / Sole invocation boundary defending against malformed foreign energy capabilities. */
public final class EnergyCapabilityGuard {
    private static final Logger LOGGER = LoggerFactory.getLogger(EnergyCapabilityGuard.class);
    private static final int MAX_LOGGED_FAILURES = 256;
    private static final Set<String> LOGGED_FAILURES = ConcurrentHashMap.newKeySet();

    private EnergyCapabilityGuard() {}

    /** 安全解析并包装第三方能力；解析失败视为能力不存在。 / Safely resolves and wraps a foreign capability; failures mean unavailable. */
    @Nullable
    public static IEnergyStorage resolve(Supplier<IEnergyStorage> resolver) {
        if (resolver == null) return null;
        IEnergyStorage storage = call("resolve", resolver, resolver, null);
        return storage == null ? null : wrap(storage);
    }

    /** 执行一次外部协议调用，普通集成故障时返回封闭失败值。 / Executes a foreign protocol call and fails closed on integration errors. */
    public static <T> T call(String operation, Object owner, Supplier<T> call, T fallback) {
        if (call == null) return fallback;
        try {
            return call.get();
        } catch (RuntimeException | LinkageError failure) {
            logOnce(operation, owner, failure);
            return fallback;
        }
    }

    /** 返回隔离异常并约束数值范围的外部存储视图。 / Returns an exception-isolating, range-clamping view of foreign storage. */
    public static IEnergyStorage wrap(IEnergyStorage storage) {
        if (storage instanceof GuardedStorage) return storage;
        return new GuardedStorage(storage);
    }

    private static void logOnce(String operation, Object owner, Throwable failure) {
        if (LOGGED_FAILURES.size() >= MAX_LOGGED_FAILURES) return;
        String ownerName = owner == null ? "unknown"
                : owner instanceof Class<?> type ? type.getName() : owner.getClass().getName();
        String key = operation + ':' + ownerName + ':' + failure.getClass().getName();
        if (LOGGED_FAILURES.add(key)) {
            LOGGER.warn("Ignored failing external energy capability operation {} from {} ({})",
                    operation, ownerName, failure.getClass().getName());
        }
    }

    private static final class GuardedStorage implements IEnergyStorage {
        private final IEnergyStorage delegate;

        private GuardedStorage(IEnergyStorage delegate) {
            this.delegate = delegate;
        }

        @Override
        public int receiveEnergy(int maxReceive, boolean simulate) {
            int request = Math.max(0, maxReceive);
            if (request == 0) return 0;
            try {
                return Math.max(0, Math.min(request, delegate.receiveEnergy(request, simulate)));
            } catch (RuntimeException | LinkageError failure) {
                logOnce("receiveEnergy", delegate, failure);
                return 0;
            }
        }

        @Override
        public int extractEnergy(int maxExtract, boolean simulate) {
            int request = Math.max(0, maxExtract);
            if (request == 0) return 0;
            try {
                return Math.max(0, Math.min(request, delegate.extractEnergy(request, simulate)));
            } catch (RuntimeException | LinkageError failure) {
                logOnce("extractEnergy", delegate, failure);
                return 0;
            }
        }

        @Override
        public int getEnergyStored() {
            try {
                return Math.max(0, delegate.getEnergyStored());
            } catch (RuntimeException | LinkageError failure) {
                logOnce("getEnergyStored", delegate, failure);
                return 0;
            }
        }

        @Override
        public int getMaxEnergyStored() {
            try {
                return Math.max(0, delegate.getMaxEnergyStored());
            } catch (RuntimeException | LinkageError failure) {
                logOnce("getMaxEnergyStored", delegate, failure);
                return 0;
            }
        }

        @Override
        public boolean canExtract() {
            try {
                return delegate.canExtract();
            } catch (RuntimeException | LinkageError failure) {
                logOnce("canExtract", delegate, failure);
                return false;
            }
        }

        @Override
        public boolean canReceive() {
            try {
                return delegate.canReceive();
            } catch (RuntimeException | LinkageError failure) {
                logOnce("canReceive", delegate, failure);
                return false;
            }
        }
    }
}
