package ic2cre.api.energy;

import net.minecraft.core.Direction;

/** 声明需求、电压等级和注入语义的能源接收节点。 / Energy sink declaring demand, voltage tier, and injection behavior. */
public interface IEnergySink extends IEnergyAcceptor {

    long getDemandedEnergy();

    int getSinkTier();

    /** 返回接收端拒绝的 mEU 余量。 / Returns the rejected mEU remainder. */
    long injectEnergy(Direction directionFrom, long amount, long voltage);
}
