package ic2cre.api.energy;

/** 控制能源容器操作是模拟还是修改状态。 / Controls whether an energy-container operation simulates or mutates state. */
public enum EnergyAction {
    SIMULATE,
    EXECUTE;

    public boolean execute() { return this == EXECUTE; }
    public boolean simulate() { return this == SIMULATE; }
}
