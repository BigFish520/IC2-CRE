package ic2cre.api.energy;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;
import org.jetbrains.annotations.Nullable;
import java.util.Objects;

/** 默认的可变 mEU 容器。 / Default mutable mEU container. */
public class BasicEnergyContainer implements IEnergyContainer, INBTSerializable<CompoundTag> {
    private long stored;
    private long maxEnergy;
    private final Runnable changeListener;

    public BasicEnergyContainer(long maxEnergy, @Nullable Runnable changeListener) {
        this.maxEnergy = Math.max(0L, maxEnergy);
        this.changeListener = changeListener;
    }

    public static BasicEnergyContainer create(long maxEnergy, Runnable changeListener) {
        return new BasicEnergyContainer(maxEnergy, Objects.requireNonNull(changeListener));
    }

    @Override public long getEnergy() { return stored; }
    @Override public long getMaxEnergy() { return maxEnergy; }

    @Override
    public void setEnergy(long energy) {
        long clamped = Math.max(0L, Math.min(energy, maxEnergy));
        if (clamped == stored) return;
        stored = clamped;
        onContentsChanged();
    }

    public void setMaxEnergy(long maxEnergy) {
        long newMaximum = Math.max(0L, maxEnergy);
        if (this.maxEnergy == newMaximum) return;
        this.maxEnergy = newMaximum;
        if (stored > newMaximum) stored = newMaximum;
        onContentsChanged();
    }

    @Override public void onContentsChanged() { if (changeListener != null) changeListener.run(); }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        CompoundTag tag = new CompoundTag();
        if (stored > 0L) tag.putLong("energy", stored);
        return tag;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag tag) {
        stored = Math.max(0L, Math.min(tag.getLong("energy"), maxEnergy));
    }
}
