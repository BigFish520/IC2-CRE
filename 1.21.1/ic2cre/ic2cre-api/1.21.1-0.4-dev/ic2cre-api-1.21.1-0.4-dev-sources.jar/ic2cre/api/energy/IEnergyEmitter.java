package ic2cre.api.energy;

import net.minecraft.core.Direction;

/** 可向相邻能源节点发送能量的节点。 / Node that can emit energy to an adjacent energy tile. */
public interface IEnergyEmitter extends IEnergyTile {

    boolean emitsEnergyTo(IEnergyAcceptor acceptor, Direction direction);
}
