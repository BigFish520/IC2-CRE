package ic2cre.api.energy;

/**
 * 仅允许在能源网络适配边界出现的外部单位；网络内部始终使用 mEU。
 * / External units allowed only at adapter boundaries; the network always stores mEU internally.
 */
public enum ExternalEnergyUnit {
    EU,
    AE,
    RF,
    J,
    FE;

    public long toInternal(long amount) {
        return EnergyNetConversion.toInternal(this, amount);
    }

    public long fromInternal(long milliEu) {
        return EnergyNetConversion.fromInternal(this, milliEu);
    }

    public long getMilliEuPerUnit() {
        return EnergyNetConversion.milliEuPerUnit(this);
    }
}
