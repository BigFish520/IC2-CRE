package ic2cre.api.energy.prefab;

import ic2cre.api.energy.IEnergyEmitter;
import ic2cre.api.energy.IEnergySink;
import ic2cre.api.energy.EnergyTier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** 接受所有方向输入的基础能源接收器。 / Basic energy sink accepting input from every direction. */
public class BasicSink extends BasicEnergyTile implements IEnergySink {
    protected int tier;

    public BasicSink(BlockEntity parent, long capacity, int tier) {
        super(parent, capacity);
        setSinkTier(tier);
    }

    public BasicSink(Level level, BlockPos pos, long capacity, int tier) {
        super(level, pos, capacity);
        setSinkTier(tier);
    }

    public void setSinkTier(int tier) {
        if (tier < 0 || tier > EnergyTier.MAX_LEVEL) throw new IllegalArgumentException("invalid tier: " + tier);
        this.tier = tier;
    }

    @Override public boolean acceptsEnergyFrom(IEnergyEmitter emitter, Direction direction) { return true; }
    @Override public long getDemandedEnergy() { return getFreeCapacity(); }
    @Override public int getSinkTier() { return tier; }

    @Override
    public long injectEnergy(Direction directionFrom, long amount, long voltage) {
        long accepted = addEnergy(amount);
        return Math.max(0L, amount - accepted);
    }

    @Override protected String getNbtTagName() { return "ic2cre_basic_sink_energy"; }
}
