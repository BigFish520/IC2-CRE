package ic2cre.api.energy;

/**
 * 公共 API 与运行时共用的定点 EU 运算；1000 mEU = 1 EU。
 * / Fixed-point EU arithmetic shared by the API and runtime; 1000 mEU = 1 EU.
 */
public final class EnergyUnits {
    public static final long SCALE = 1_000L;

    private EnergyUnits() {
    }

    public static long ofEu(long eu) {
        return saturatingMultiply(eu, SCALE);
    }

    public static long ofMilliEu(long milliEu) {
        return milliEu;
    }

    public static long floorEu(long fixed) {
        return fixed / SCALE;
    }

    public static long ceilEu(long fixed) {
        if (fixed <= 0) return 0;
        return 1L + (fixed - 1L) / SCALE;
    }

    public static long saturatingAdd(long left, long right) {
        if (right > 0 && left > Long.MAX_VALUE - right) return Long.MAX_VALUE;
        if (right < 0 && left < Long.MIN_VALUE - right) return Long.MIN_VALUE;
        return left + right;
    }

    public static long saturatingMultiply(long value, long multiplier) {
        if (value == 0 || multiplier == 0) return 0;
        if (value > 0 && multiplier > 0 && value > Long.MAX_VALUE / multiplier) return Long.MAX_VALUE;
        if (value < 0 && multiplier < 0 && value < Long.MAX_VALUE / multiplier) return Long.MAX_VALUE;
        if (value > 0 && multiplier < 0 && multiplier < Long.MIN_VALUE / value) return Long.MIN_VALUE;
        if (value < 0 && multiplier > 0 && value < Long.MIN_VALUE / multiplier) return Long.MIN_VALUE;
        return value * multiplier;
    }
}
