package ic2cre.api.energy;

/** 允许节点安全处理过载的契约。 / Contract allowing a tile to handle overloads safely. */
public interface IOverloadHandler {
    /** 已处理过载且不应爆炸时返回 true。 / Returns true when the overload was handled and must not explode. */
    boolean onOverload(int tier);
}
