package ic2cre.api.energy;

/** 允许能源节点覆盖过载爆炸行为。 / Allows an energy tile to override overload explosion behavior. */
public interface IExplosionPowerOverride {

    boolean shouldExplode();

    float getExplosionPower(int tier, float defaultPower);
}
