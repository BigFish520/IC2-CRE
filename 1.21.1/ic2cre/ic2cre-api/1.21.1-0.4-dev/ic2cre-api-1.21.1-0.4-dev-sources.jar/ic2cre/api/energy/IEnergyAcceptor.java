package ic2cre.api.energy;

import net.minecraft.core.Direction;

/** 可从相邻能源节点接收能量的节点。 / Node that can accept energy from an adjacent energy tile. */
public interface IEnergyAcceptor extends IEnergyTile {

    boolean acceptsEnergyFrom(IEnergyEmitter emitter, Direction direction);
}
