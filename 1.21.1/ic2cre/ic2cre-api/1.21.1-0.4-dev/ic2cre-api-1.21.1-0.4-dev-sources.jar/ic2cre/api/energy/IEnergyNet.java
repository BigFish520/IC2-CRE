package ic2cre.api.energy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/** 感知维度的公共能源网络门面。 / Public level-aware EnergyNet facade. */
public interface IEnergyNet {

    static IEnergyNet get(Level level) {
        return EnergyNet.getInstance();
    }

    @Nullable IEnergyTile getTile(Level level, BlockPos pos);

    void addTile(Level level, IEnergyTile tile, BlockPos pos);

    void removeTile(IEnergyTile tile);

    /** 朝向、颜色或导体数据变化后重建缓存连接。 / Rebuilds cached connections after connection data changes. */
    void updateTile(IEnergyTile tile);

    @Nullable Level getWorld(IEnergyTile tile);

    @Nullable BlockPos getPos(IEnergyTile tile);

    @Nullable NodeStats getNodeStats(IEnergyTile tile);

    long getPowerFromTier(int tier);

    int getTierFromPower(long power);

    /** 将外部单位换算为 mEU 后注入。 / Injects an external-unit packet after converting it to mEU. */
    long receiveExternal(Level level, BlockPos pos, Direction side,
                         ExternalEnergyUnit unit, long amount, EnergyAction action);

    /** 在边界提取 mEU 并按请求单位返回。 / Extracts mEU at the boundary and returns the requested unit. */
    long extractExternal(Level level, BlockPos pos, Direction side,
                         ExternalEnergyUnit unit, long amount, EnergyAction action);

    void registerEventReceiver(IEnergyNetEventReceiver receiver);

    void unregisterEventReceiver(IEnergyNetEventReceiver receiver);
}
