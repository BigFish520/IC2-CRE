package ic2cre.api.energy;

/** 使用 long 保存的内部 mEU 缓冲区。 / Internal mEU buffer backed by long values. */
public interface IEnergyContainer {
    long getEnergy();
    void setEnergy(long energy);
    long getMaxEnergy();

    default long getNeeded() { return Math.max(0L, getMaxEnergy() - getEnergy()); }

    /**
     * 尝试插入能量并返回未接收的余量。 / Attempts insertion and returns the unaccepted remainder.
     */
    default long insert(long amount, EnergyAction action) {
        if (amount <= 0L) return 0L;
        long accepted = Math.min(amount, getNeeded());
        if (accepted > 0L && action.execute()) setEnergy(getEnergy() + accepted);
        return amount - accepted;
    }

    /**
     * 尝试提取能量并返回实际提取量。 / Attempts extraction and returns the amount actually extracted.
     */
    default long extract(long amount, EnergyAction action) {
        if (amount <= 0L) return 0L;
        long extracted = Math.min(amount, getEnergy());
        if (extracted > 0L && action.execute()) setEnergy(getEnergy() - extracted);
        return extracted;
    }

    default boolean isEmpty() { return getEnergy() <= 0L; }
    default void setEmpty() { setEnergy(0L); }
    default void onContentsChanged() {}
}
