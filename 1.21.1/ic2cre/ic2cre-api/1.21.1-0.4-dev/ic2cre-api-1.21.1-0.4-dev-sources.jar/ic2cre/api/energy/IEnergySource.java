package ic2cre.api.energy;

/** 声明可供能量和输出等级的能源源节点。 / Energy source declaring offered energy and output tier. */
public interface IEnergySource extends IEnergyEmitter {

    long getOfferedEnergy();

    void drawEnergy(long amount);

    int getSourceTier();
}
