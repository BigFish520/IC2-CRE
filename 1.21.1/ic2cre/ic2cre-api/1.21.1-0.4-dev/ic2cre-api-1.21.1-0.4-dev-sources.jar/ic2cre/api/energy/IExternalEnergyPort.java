package ic2cre.api.energy;

import net.minecraft.core.Direction;

/**
 * 第三方能源系统的换算边界；实现必须立即换算，能源网络不得存储外部单位。
 * / Conversion boundary for third-party energy systems; foreign units must be converted immediately and never stored.
 */
public interface IExternalEnergyPort {
    long receive(ExternalEnergyUnit unit, long amount, Direction side, EnergyAction action);

    long extract(ExternalEnergyUnit unit, long amount, Direction side, EnergyAction action);

    long getStored(ExternalEnergyUnit unit, Direction side);

    long getCapacity(ExternalEnergyUnit unit, Direction side);

    boolean canReceive(Direction side);

    boolean canExtract(Direction side);
}
