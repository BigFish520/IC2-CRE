package ic2cre.api.energy.prefab;

import ic2cre.api.energy.EnergyNet;
import ic2cre.api.energy.IEnergyTile;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.jetbrains.annotations.Nullable;

/** 使用 mEU 的 IC2 基础能源节点组合 helper。 / Composable IC2 basic energy-tile helper using mEU. */
public abstract class BasicEnergyTile implements IEnergyTile {
    @Nullable
    private final BlockEntity parent;
    @Nullable
    protected Level level;
    @Nullable
    protected BlockPos pos;
    protected long capacity;
    protected long energyStored;
    private boolean addedToEnergyNet;

    protected BasicEnergyTile(BlockEntity parent, long capacity) {
        if (parent == null) throw new NullPointerException("parent");
        this.parent = parent;
        if (capacity < 0L) throw new IllegalArgumentException("capacity must not be negative");
        this.capacity = capacity;
    }

    protected BasicEnergyTile(Level level, BlockPos pos, long capacity) {
        if (level == null || pos == null) throw new NullPointerException("level/pos");
        this.parent = null;
        this.level = level;
        this.pos = pos.immutable();
        if (capacity < 0L) throw new IllegalArgumentException("capacity must not be negative");
        this.capacity = capacity;
    }

    public void onLoad() {
        resolveLocation();
        var energyNet = EnergyNet.getIfPresent();
        if (!addedToEnergyNet && level != null && pos != null && !level.isClientSide()
                && energyNet != null) {
            energyNet.addTile(level, this, pos);
            addedToEnergyNet = true;
        }
    }

    public void invalidate() {
        if (!addedToEnergyNet) return;
        addedToEnergyNet = false;
        var energyNet = EnergyNet.getIfPresent();
        if (energyNet != null) {
            energyNet.removeTile(this);
        }
    }

    @Override
    public boolean isEnergyTileValid(Level expectedLevel, BlockPos expectedPos) {
        if (!addedToEnergyNet || level != expectedLevel || pos == null
                || !pos.equals(expectedPos)) return false;
        return parent == null || (!parent.isRemoved() && parent.getLevel() == expectedLevel
                && expectedLevel.getBlockEntity(expectedPos) == parent);
    }

    public void load(CompoundTag tag) {
        setEnergyStored(tag.getLong(getNbtTagName()));
    }

    public void save(CompoundTag tag) {
        tag.putLong(getNbtTagName(), energyStored);
    }

    public long getCapacity() { return capacity; }

    public void setCapacity(long capacity) {
        if (capacity < 0L) throw new IllegalArgumentException("capacity must not be negative");
        this.capacity = capacity;
        if (energyStored > this.capacity) energyStored = this.capacity;
    }

    public long getEnergyStored() { return energyStored; }

    public void setEnergyStored(long amount) {
        energyStored = Math.max(0L, Math.min(capacity, amount));
    }

    public long getFreeCapacity() { return Math.max(0L, capacity - energyStored); }

    public long addEnergy(long amount) {
        long accepted = Math.min(Math.max(0L, amount), getFreeCapacity());
        energyStored += accepted;
        return accepted;
    }

    public boolean useEnergy(long amount) {
        if (amount < 0L || energyStored < amount) return false;
        energyStored -= amount;
        return true;
    }

    protected abstract String getNbtTagName();

    private void resolveLocation() {
        if (parent == null) return;
        level = parent.getLevel();
        pos = parent.getBlockPos();
    }
}
