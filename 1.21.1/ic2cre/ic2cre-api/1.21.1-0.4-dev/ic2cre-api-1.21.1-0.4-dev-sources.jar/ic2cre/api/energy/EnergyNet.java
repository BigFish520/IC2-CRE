package ic2cre.api.energy;

import org.jetbrains.annotations.Nullable;

/** IC2CRE 能源网络实现的公共入口。 / Public entry point for IC2CRE's EnergyNet implementation. */
public final class EnergyNet {

    @Nullable
    private static volatile IEnergyNet instance;

    private EnergyNet() {
    }

    public static IEnergyNet getInstance() {
        IEnergyNet current = instance;
        if (current == null) throw new IllegalStateException("IC2CRE EnergyNet is not bound");
        return current;
    }

    /** 尚未绑定时返回 null。 / Returns null while the runtime has not bound the network. */
    @Nullable
    public static IEnergyNet getIfPresent() {
        return instance;
    }

    /** 由 common 运行时在模组初始化期间绑定。 / Bound by the common runtime during mod initialization. */
    public static void bind(IEnergyNet energyNet) {
        if (energyNet == null) throw new NullPointerException("energyNet");
        IEnergyNet current = instance;
        if (current != null && current != energyNet) {
            throw new IllegalStateException("IC2CRE EnergyNet is already bound");
        }
        instance = energyNet;
    }
}
