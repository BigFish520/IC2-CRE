package ic2cre.api.energy;

/** 定义传输损耗及绝缘、导体击穿阈值的能源导体。 / Energy conductor defining loss and insulation/conductor breakdown thresholds. */
public interface IEnergyConductor extends IEnergyAcceptor, IEnergyEmitter {

    long getConductionLoss();

    long getInsulationEnergyAbsorption();

    long getInsulationBreakdownEnergy();

    long getConductorBreakdownEnergy();

    void removeInsulation();

    void removeConductor();
}
