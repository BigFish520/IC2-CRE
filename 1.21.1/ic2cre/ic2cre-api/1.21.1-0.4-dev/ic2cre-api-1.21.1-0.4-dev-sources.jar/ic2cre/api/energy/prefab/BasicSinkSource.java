package ic2cre.api.energy.prefab;

import ic2cre.api.energy.EnergyTier;
import ic2cre.api.energy.IEnergyAcceptor;
import ic2cre.api.energy.IEnergyEmitter;
import ic2cre.api.energy.IEnergySink;
import ic2cre.api.energy.IEnergySource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** 可同时接收和发送能量的基础节点。 / Basic tile capable of receiving and emitting energy. */
public class BasicSinkSource extends BasicEnergyTile implements IEnergySink, IEnergySource {
    protected int sinkTier;
    protected int sourceTier;

    public BasicSinkSource(BlockEntity parent, long capacity, int sinkTier, int sourceTier) {
        super(parent, capacity);
        setSinkTier(sinkTier);
        setSourceTier(sourceTier);
    }

    public BasicSinkSource(Level level, BlockPos pos, long capacity, int sinkTier, int sourceTier) {
        super(level, pos, capacity);
        setSinkTier(sinkTier);
        setSourceTier(sourceTier);
    }

    public void setSinkTier(int tier) {
        if (tier < 0 || tier > EnergyTier.MAX_LEVEL) throw new IllegalArgumentException("invalid tier: " + tier);
        sinkTier = tier;
    }

    public void setSourceTier(int tier) {
        if (tier < 0 || tier > EnergyTier.MAX_LEVEL) throw new IllegalArgumentException("invalid tier: " + tier);
        sourceTier = tier;
        if (capacity < EnergyTier.getPowerFromTier(tier)) setCapacity(EnergyTier.getPowerFromTier(tier));
    }

    @Override public boolean acceptsEnergyFrom(IEnergyEmitter emitter, Direction direction) { return true; }
    @Override public boolean emitsEnergyTo(IEnergyAcceptor acceptor, Direction direction) { return true; }
    @Override public long getDemandedEnergy() { return getFreeCapacity(); }
    @Override public int getSinkTier() { return sinkTier; }
    @Override public long getOfferedEnergy() { return energyStored; }
    @Override public void drawEnergy(long amount) { useEnergy(Math.max(0L, amount)); }
    @Override public int getSourceTier() { return sourceTier; }

    @Override
    public long injectEnergy(Direction directionFrom, long amount, long voltage) {
        long accepted = addEnergy(amount);
        return Math.max(0L, amount - accepted);
    }

    @Override protected String getNbtTagName() { return "ic2cre_basic_sink_source_energy"; }
}
