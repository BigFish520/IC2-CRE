package ic2cre.api.energy.prefab;

import ic2cre.api.energy.EnergyTier;
import ic2cre.api.energy.IEnergyAcceptor;
import ic2cre.api.energy.IEnergySource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** 向所有方向输出的基础能源源。 / Basic energy source emitting in every direction. */
public class BasicSource extends BasicEnergyTile implements IEnergySource {
    protected int tier;

    public BasicSource(BlockEntity parent, long capacity, int tier) {
        super(parent, capacity);
        setSourceTier(tier);
    }

    public BasicSource(Level level, BlockPos pos, long capacity, int tier) {
        super(level, pos, capacity);
        setSourceTier(tier);
    }

    public void setSourceTier(int tier) {
        if (tier < 0 || tier > EnergyTier.MAX_LEVEL) throw new IllegalArgumentException("invalid tier: " + tier);
        this.tier = tier;
        if (capacity < EnergyTier.getPowerFromTier(tier)) setCapacity(EnergyTier.getPowerFromTier(tier));
    }

    @Override public boolean emitsEnergyTo(IEnergyAcceptor acceptor, Direction direction) { return true; }
    @Override public long getOfferedEnergy() { return energyStored; }
    @Override public void drawEnergy(long amount) { useEnergy(Math.max(0L, amount)); }
    @Override public int getSourceTier() { return tier; }
    @Override protected String getNbtTagName() { return "ic2cre_basic_source_energy"; }
}
