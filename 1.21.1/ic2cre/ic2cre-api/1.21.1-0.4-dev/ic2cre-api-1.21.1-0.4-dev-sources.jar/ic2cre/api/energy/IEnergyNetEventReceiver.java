package ic2cre.api.energy;

/** 接收能源节点加入和移除事件。 / Receives EnergyNet tile addition and removal events. */
public interface IEnergyNetEventReceiver {
    void onAdd(IEnergyTile tile);

    void onRemove(IEnergyTile tile);
}
