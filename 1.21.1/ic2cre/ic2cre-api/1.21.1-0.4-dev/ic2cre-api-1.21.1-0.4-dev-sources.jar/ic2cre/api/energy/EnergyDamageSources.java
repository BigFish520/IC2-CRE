package ic2cre.api.energy;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/** 提供能源网络电击伤害类型及其判定。 / Provides the EnergyNet electricity damage source and its predicate. */
public final class EnergyDamageSources {
    public static final ResourceKey<DamageType> ELECTRICITY = ResourceKey.create(
            Registries.DAMAGE_TYPE, Ic2CreAPI.resource("electricity"));

    private EnergyDamageSources() {}

    public static DamageSource electricity(Level level) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(ELECTRICITY));
    }

    public static DamageSource electricity(Level level, Entity causingEntity) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(ELECTRICITY), causingEntity);
    }

    public static boolean isElectricity(DamageSource source) {
        return source != null && source.typeHolder().unwrapKey().map(ELECTRICITY::equals).orElse(false);
    }
}
