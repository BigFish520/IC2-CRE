package ic2cre.api.energy;

import net.minecraft.core.Direction;
import javax.annotation.Nullable;

/** 向 IC2CRE 集成公开内部 mEU 容器。 / Exposes an internal mEU container to IC2CRE integrations. */
public interface IEnergyContainerProvider {
    @Nullable IEnergyContainer getEnergyContainer();

    @Nullable
    default IEnergyContainer getEnergyContainer(@Nullable Direction side) {
        return getEnergyContainer();
    }
}
