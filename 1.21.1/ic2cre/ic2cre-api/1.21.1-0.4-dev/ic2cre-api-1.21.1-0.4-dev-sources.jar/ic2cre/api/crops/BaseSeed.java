package ic2cre.api.crops;

import java.util.Objects;

/** 种子种植时的初始性状。 / Initial crop traits supplied by a base seed. */
public record BaseSeed(CropCard crop, int size, int growth, int gain, int resistance) {
    public BaseSeed {
        Objects.requireNonNull(crop, "crop");
        if (size < 1 || size > crop.maxAge() || growth < 0 || growth > 31
                || gain < 0 || gain > 31 || resistance < 0 || resistance > 31) {
            throw new IllegalArgumentException("Invalid base seed traits");
        }
    }
}
