package ic2cre.api.crops;


import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Abstract crop card — defines a crop's behavior, properties, and drops.
 * 抽象作物卡 — 定义作物的行为、属性和掉落物。
 * <p>
 * Port of {@code ic2.api.crops.CropCard}. Each crop type (Weed, Wheat, etc.) is a subclass.
 * 对标 {@code ic2.api.crops.CropCard}。每种作物（杂草、小麦等）是一个子类。
 */
public abstract class CropCard {

    private final String id;

    protected CropCard(String id) {
        this.id = Objects.requireNonNull(id, "id");
        if (!id.matches("[a-z0-9_]+") && net.minecraft.resources.ResourceLocation.tryParse(id) == null) {
            throw new IllegalArgumentException("Invalid crop id: " + id);
        }
    }

    public String getId() { return id; }

    protected CropCard(net.minecraft.resources.ResourceLocation id) {
        this(id.getNamespace().equals("ic2cre") ? id.getPath() : id.toString());
    }

    public net.minecraft.resources.ResourceLocation getResourceLocation() {
        return id.contains(":") ? net.minecraft.resources.ResourceLocation.parse(id)
                : net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("ic2cre", id);
    }

    // ═══ Properties / 属性 ═══

    /** 返回杂交使用的六维属性向量。 / Returns the six-dimensional attribute vector used for cross-breeding. */
    public abstract CropProperties properties();

    /** 返回本地化显示名键。 / Returns the localized display-name key. */
    public abstract String getDisplayName();


    public int tier() { return properties().tier(); }

    // ═══ Growth / 生长 ═══


    public abstract int growthDuration();


    public int growthDuration(ICropTile crop) { return growthDuration(); }


    public int maxAge() { return 4; }


    public int minHarvestAge() { return maxAge(); }


    public List<net.minecraft.resources.ResourceLocation> getTexturesLocation() {
        List<net.minecraft.resources.ResourceLocation> result = new java.util.ArrayList<>(maxAge());
        for (int size = 1; size <= maxAge(); size++) {
            var key = getResourceLocation();
            result.add(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(key.getNamespace(), "block/crop/" + key.getPath() + "_" + size));
        }
        return result;
    }


    public int textureStage(int currentSize) { return currentSize; }

    // ═══ Cross-breeding / 杂交 ═══


    public boolean canCross() { return true; }


    public boolean canGrow() { return true; }


    public boolean canGrow(ICropTile crop) {
        return canGrow() && crop != null && crop.getCurrentSize() < maxAge() && canGrowAt(crop);
    }


    public boolean canGrowAt(ICropTile crop) { return true; }

    /** 根据当前作物状态判断能否参与杂交。 / Checks whether the current crop state can participate in cross-breeding. */
    public boolean canCross(ICropTile crop) {
        return canCross() && crop != null && crop.getCurrentSize() >= 3;
    }


    public void tick(ICropTile crop) { }


    public List<String> attributes() { return Collections.emptyList(); }

    // ═══ Weed / 杂草 ═══


    public boolean isWeed(ICropTile crop) {
        return crop != null
                && crop.getCurrentSize() >= 2
                && ((crop.getCrop() != null && crop.getCrop().isWeedSpecies()) || crop.getStatGrowth() >= 24);
    }

    public boolean isWeedSpecies() { return false; }

    // ═══ Harvest / 收获 ═══


    public abstract ItemLike getDrop();


    public float dropChance() { return 0.75F; }


    public List<ItemStack> getDrops(ICropTile crop) {
        ItemLike drop = getDrop();
        if (drop == null) return Collections.emptyList();
        float chance = (float) (dropChance() * Math.pow(1.03, crop.getStatGain()));
        int count = 0;
        while (count < 3 && crop.getWorld().getRandom().nextFloat() < chance) {
            count++;
        }
        if (count > 0) {
            return Collections.singletonList(new ItemStack(drop, count));
        }
        return Collections.emptyList();
    }


    public List<ItemStack> getHarvestDrops(ICropTile crop) {
        double chance = dropGainChance() * Math.pow(1.03, crop.getStatGain());
        int dropCount = (int) Math.max(0L, Math.round(
                crop.getWorld().getRandom().nextGaussian() * chance * 0.6827 + chance));
        List<ItemStack> result = new java.util.ArrayList<>();
        for (int i = 0; i < dropCount; i++) {
            for (ItemStack drop : getGains(crop)) {
                if (drop.isEmpty()) continue;
                ItemStack copy = drop.copy();
                if (crop.getWorld().getRandom().nextInt(100) <= crop.getStatGain()) copy.grow(1);
                result.add(copy);
            }
        }
        return result;
    }

    /** Extra seed drop chance / 额外种子掉落概率 */
    public float seedDropChance(ICropTile crop) {
        if (crop == null || crop.getCurrentSize() <= 1) return 0.0F;
        float base = 0.5F;
        if (crop.getCurrentSize() == 2) base /= 2.0F;
        for (int i = 0; i < tier(); i++) base *= 0.8F;
        return base;
    }

    // ═══ Harvest API (for TileEntityCrop.performHarvest) / 收获 API ═══


    public boolean canBeHarvested(ICropTile crop) {
        return crop != null && crop.getCurrentSize() >= minHarvestAge();
    }


    public int getOptimalHarvestSize(ICropTile crop) { return getMaxSize(crop); }


    public int getMaxSize(ICropTile crop) { return maxAge(); }


    public int getSizeAfterHarvest(ICropTile crop) { return 1; }


    public double dropGainChance() { return Math.pow(0.95, tier()); }


    public ItemStack[] getGains(ICropTile crop) {
        ItemLike drop = getDrop();
        if (drop == null) return new ItemStack[0];
        return new ItemStack[]{ new ItemStack(drop) };
    }

    // ═══ Growth / 生长 ═══


    public int maxVisualSize() { return maxAge(); }

    // ═══ Environment / 环境 ═══


    public boolean canGrowAt(ICropTile crop, int humidity, int nutrients, int air) {
        return true;
    }


    public int getWeightInfluences(ICropTile crop, int humidity, int nutrients, int airQuality) {
        return humidity + nutrients + airQuality;
    }

    @Override
    public String toString() { return "CropCard[" + id + "]"; }
}
