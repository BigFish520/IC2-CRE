package ic2cre.api.crops;

import java.util.Collection;

/** 作物扩展在 common setup 的排队工作中注册，开始游戏后只读。 / Register extensions in enqueued common setup work; read only once gameplay starts. */
public interface ICropRegistry {
    <T extends CropCard> T register(T crop);
    CropCard get(String id);
    Collection<CropCard> values();
    boolean registerBaseSeed(net.minecraft.world.item.ItemStack stack, BaseSeed seed);
    BaseSeed getBaseSeed(net.minecraft.world.item.ItemStack stack);
}
