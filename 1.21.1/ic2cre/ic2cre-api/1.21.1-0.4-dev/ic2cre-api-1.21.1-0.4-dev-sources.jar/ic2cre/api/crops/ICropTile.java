package ic2cre.api.crops;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/**
 * Interface for crop tile entities — provides read access to crop state.
 * 作物 TileEntity 接口 — 提供作物状态的读取访问。
 */
public interface ICropTile {


    CropCard getCrop();


    int getCurrentAge();


    int getCurrentSize();


    int getStatGrowth();


    int getStatGain();


    int getStatResistance();


    int getScanLevel();


    int getHydration();


    int getNutrients();


    int getAirQuality();

    int getStorageWater();
    int getStorageNutrients();
    int getStorageWeedEx();
    int getTerrainHumidity();
    int getTerrainNutrients();
    int getTerrainAirQuality();
    int getGrowthPoints();
    void setGrowthPoints(int value);
    int getLightLevel();
    boolean isBlockBelow(net.minecraft.world.level.block.Block block);


    Level getWorld();


    BlockPos getPos();


    void setCrop(CropCard crop, int growth, int gain, int resistance);


    void setStats(int growth, int gain, int resistance);


    void addHydration(int amount);


    void addNutrients(int amount);


    void addWeedEx(int amount);
}
