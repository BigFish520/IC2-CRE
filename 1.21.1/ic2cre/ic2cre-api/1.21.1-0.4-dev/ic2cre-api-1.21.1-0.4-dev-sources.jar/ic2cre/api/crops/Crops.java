package ic2cre.api.crops;

import java.util.Objects;

/** 作物注册与查询的运行时入口。 / Runtime entry point for crop registration and lookup. */
public final class Crops {
    private static volatile ICropRegistry registry;

    private Crops() {}

    public static ICropRegistry getRegistry() {
        return Objects.requireNonNull(registry, "IC2CRE crop service is not bound");
    }

    public static synchronized void bind(ICropRegistry implementation) {
        Objects.requireNonNull(implementation, "implementation");
        if (registry != null && registry != implementation) {
            throw new IllegalStateException("IC2CRE crop service is already bound");
        }
        registry = implementation;
    }
}
