package ic2cre.api.crops;

/**
 * Crop properties — the 6-dimensional attribute vector used for cross-breeding compatibility.
 * 作物属性 — 用于杂交兼容性计算的 6 维属性向量。
 * <p>
 * Port of {@code ic2.api.crops.CropProperties}. Lower property difference between
 * two crops = higher chance of producing a child crop during cross-breeding.
 * 对标 {@code ic2.api.crops.CropProperties}。两种作物间属性差异越小 = 杂交产出子代的概率越高。
 *
 * @param tier       Difficulty tier (0–6+), drives growth duration and seed penalties
 * @param chemistry  Chemistry axis (0–4)
 * @param consumable Consumable axis (0–4)
 * @param defensive  Defensive axis (0–4)
 * @param colorful   Colorful axis (0–4)
 * @param weed       Weed axis (0–5, 5 = pure weed)
 */
public record CropProperties(int tier, int chemistry, int consumable, int defensive, int colorful, int weed) {

    public CropProperties {
        if (tier < 0 || chemistry < 0 || consumable < 0 || defensive < 0 || colorful < 0 || weed < 0) {
            throw new IllegalArgumentException("Crop properties must be non-negative");
        }
    }

    /** 纯杂草属性：tier 0，仅防御为 1、杂草性为 5。 / Pure-weed properties: tier 0, defensive 1, and weed 5. */
    public static final CropProperties WEED = new CropProperties(0, 0, 0, 1, 0, 5);

    /** 创建仅 tier 不同的副本。 / Creates a copy differing only in tier. */
    public CropProperties withTier(int newTier) { return new CropProperties(newTier, chemistry, consumable, defensive, colorful, weed); }
}
