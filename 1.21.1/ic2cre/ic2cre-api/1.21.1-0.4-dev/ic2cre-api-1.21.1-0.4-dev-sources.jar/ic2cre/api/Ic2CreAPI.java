package ic2cre.api;

import net.minecraft.resources.ResourceLocation;

/**
 * IC2CRE 公共 API 的稳定命名空间入口。 / Stable namespace entry point for the IC2CRE public API.
 *
 * <p>API 代码只能依赖 Minecraft、NeoForge、IC2CRE EnergyNet 与其他 API 类型，不能依赖运行时实现。
 * / API code may depend only on Minecraft, NeoForge, IC2CRE EnergyNet, and other API types—not runtime implementation.</p>
 */
public final class Ic2CreAPI {

    public static final String MOD_ID = "ic2cre";

    private Ic2CreAPI() {
    }

    /** 创建 IC2CRE 资源坐标。 / Creates an IC2CRE resource location. */
    public static ResourceLocation resource(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }
}
