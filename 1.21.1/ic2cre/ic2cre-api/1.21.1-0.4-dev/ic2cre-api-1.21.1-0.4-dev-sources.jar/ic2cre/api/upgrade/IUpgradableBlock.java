package ic2cre.api.upgrade;


import java.util.Set;

/**
 * 升级件与可升级机器交互的职责接口。 / Capability contract between upgrades and upgradable machines.
 */
public interface IUpgradableBlock {

    /** 获取当前可用能量（mEU）。 / Returns currently available energy in mEU. */
    long getEnergyMeu();

    /**
     * 原子消耗指定 mEU；负数无效，零值成功且不修改状态，能量不足时不得部分扣除。
     * / Atomically consumes mEU; negatives are invalid, zero succeeds without mutation, and shortages never debit partially.
     */
    boolean consumeEnergyMeu(long amountMeu);

    /**
     * 返回调用方不可修改的受支持升级属性集合。 / Returns a caller-immutable set of supported upgrade properties.
     */
    Set<UpgradableProperty> getUpgradableProperties();
}
