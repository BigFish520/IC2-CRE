package ic2cre.api.upgrade;

import ic2cre.api.upgrade.IUpgradableBlock;
import ic2cre.api.upgrade.UpgradableProperty;
import net.minecraft.world.item.ItemStack;

import java.util.Collection;
import java.util.Set;

/** 升级物品向机器暴露的统一行为契约。 / Common behavior exposed by upgrade items to machines. */
public interface IUpgradeItem {

    double getProcessTimeMultiplier();

    double getEnergyDemandMultiplier();

    int getExtraTier();

    /** 每个升级件增加的储能，单位 mEU。 / Extra storage per upgrade item in mEU. */
    long getExtraEnergyStorageMeu();

    boolean isRedstoneInverter();


    boolean isDirectional();

    String getTypeName();

    /**
     * 检查此升级是否能安装到目标机器。
     * 默认实现检查升级类型与机器属性是否匹配。
     *
     * @param properties 机器支持的 {@link UpgradableProperty} 集合
     * @param stack      升级物品栈
     * @return true 如果可以安装
     */
    default boolean isSuitableFor(Set<UpgradableProperty> properties, ItemStack stack) {
        return true;
    }

    /**
     * 每 tick 回调 — 用于弹出/抽取等主动行为。
     *
     * @param stack 升级物品栈
     * @param block 宿主机器
     * @return true 如果执行了操作
     */
    default boolean onTick(ItemStack stack, IUpgradableBlock block) {
        return false;
    }

    /**
     * 处理结束回调 — 用于修改配方产物。
     *
     * @param stack  升级物品栈
     * @param block  宿主机器
     * @param output 原始输出
     * @return 修改后的输出
     */
    default Collection<ItemStack> onProcessEnd(ItemStack stack, IUpgradableBlock block, Collection<ItemStack> output) {
        return output;
    }

    /**
     * 每 tick 传输的物品数量（用于 ejector/pulling）。
     * 公式为 {@code 4^min(4, stackSize - 1)}，空栈按一个物品处理。 /
     * Uses {@code 4^min(4, stackSize - 1)} and treats an empty stack as one item.
     */
    default int getItemTransferAmount(int stackSize) {
        return 1 << (Math.min(4, Math.max(1, stackSize) - 1) * 2);
    }

    /**
     * 每 tick 传输的流体数量（mB，用于 fluid_ejector/pulling）。
     * 公式为 {@code 50 * 4^min(4, stackSize - 1)}，空栈按一个物品处理。 /
     * Uses {@code 50 * 4^min(4, stackSize - 1)} and treats an empty stack as one item.
     */
    default int getFluidTransferAmount(int stackSize) {
        return 50 * getItemTransferAmount(stackSize);
    }
}
