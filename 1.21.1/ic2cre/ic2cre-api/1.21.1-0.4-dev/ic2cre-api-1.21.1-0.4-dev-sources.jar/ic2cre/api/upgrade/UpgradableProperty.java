package ic2cre.api.upgrade;

/**
 * IC2 机器支持的升级职责；升级件只能安装到声明相应职责的机器。 / Upgrade responsibilities declared by IC2 machines.
 * <ul>
 *   <li>{@code PROCESSING}/{@code AUGMENTABLE}: 处理与过载。 / Processing and overclocking.</li>
 *   <li>{@code TRANSFORMER}/{@code ENERGY_STORAGE}: 电压与储能。 / Voltage and storage.</li>
 *   <li>{@code ITEM_CONSUMING}/{@code ITEM_PRODUCING}: 物品输入与输出。 / Item input and output.</li>
 *   <li>{@code FLUID_CONSUMING}/{@code FLUID_PRODUCING}: 流体输入与输出。 / Fluid input and output.</li>
 *   <li>{@code REDSTONE_SENSITIVE}: 红石控制。 / Redstone control.</li>
 * </ul>
 */
public enum UpgradableProperty {
    PROCESSING,
    AUGMENTABLE,
    TRANSFORMER,
    ENERGY_STORAGE,
    ITEM_CONSUMING,
    ITEM_PRODUCING,
    FLUID_CONSUMING,
    FLUID_PRODUCING,
    REDSTONE_SENSITIVE
}
