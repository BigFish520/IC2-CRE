package ic2cre.api.reactor;



/** Interface for reactor multi-block parts / 反应堆多方块部件接口 */
public interface IReactorChamber {

    default boolean isWall() { return false; }

    IReactor getReactor();
}
