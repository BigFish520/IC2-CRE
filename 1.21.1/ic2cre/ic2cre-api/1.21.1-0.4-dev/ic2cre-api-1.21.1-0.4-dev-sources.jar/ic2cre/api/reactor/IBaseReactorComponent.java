package ic2cre.api.reactor;

import net.minecraft.world.item.ItemStack;

/** 仅声明反应槽放置资格，不要求参与脉冲计算。 / Declares reactor-slot eligibility without requiring pulse processing. */
public interface IBaseReactorComponent {
    boolean canBePlacedIn(ItemStack stack, IReactor reactor);
}
