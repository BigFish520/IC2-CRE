package ic2cre.api.reactor;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;

/**
 * Reactor interface — exposes core state to components. / 反应堆接口 — 向组件暴露核心状态。
 */
public interface IReactor {
    net.minecraft.world.level.block.entity.BlockEntity getCoreTe();
    int getTickRate();
    /** 反应堆原始脉冲输出系数，不是 EU。 / Raw reactor pulse-output coefficient, not EU. */
    float getReactorEnergyOutput();
    /** 电模式名义产能，单位 mEU/t。 / Nominal electric-mode output in mEU/t. */
    long getReactorEnergyOutputMeu();
    void explode();
    int getHeat();
    void setHeat(int heat);
    int getMaxHeat();
    void setMaxHeat(int maxHeat);
    float getHeatEffectModifier();
    void setHeatEffectModifier(float modifier);
    void addEmitHeat(int amount);
    float addOutput(float amount);
    ItemStack getItemAt(int x, int y);
    void setItemAt(int x, int y, ItemStack stack);
    BlockPos getPos();
    boolean isFluidCooled();

    default boolean produceEnergy() { return true; }

    boolean isValidPosition(int x, int y);

    /** 增加堆芯自维护热量，并返回新值。 / Adds reactor-owned heat and returns the new value. */
    int addHeat(int amount);
}
