package ic2cre.api.reactor;

import net.minecraft.world.item.ItemStack;

/**
 * Reactor component interface — items placed in reactor slots implement this.
 * 反应堆组件接口 — 放置在反应堆槽位中的物品实现此接口。
 */
public interface IReactorComponent extends IBaseReactorComponent {

    default boolean canBePlacedIn(ItemStack stack, IReactor reactor) { return true; }

    default boolean acceptUraniumPulse(ItemStack stack, IReactor reactor, ItemStack pulsingStack,
                                       int componentX, int componentY, int pulseX, int pulseY,
                                       boolean heatrun) { return false; }

    default void processChamber(ItemStack stack, IReactor reactor, int x, int y, boolean heatrun) {}

    default void processCooling(ItemStack stack, IReactor reactor, int x, int y) {}

    default boolean canStoreHeat() { return false; }
    default boolean canStoreHeat(ItemStack stack, IReactor reactor, int x, int y) { return canStoreHeat(); }

    default int getCurrentHeat(ItemStack stack) { return 0; }
    default int getCurrentHeat(ItemStack stack, IReactor reactor, int x, int y) { return getCurrentHeat(stack); }
    default int getMaxHeat(ItemStack stack, IReactor reactor, int x, int y) {
        return 0;
    }

    default int alterHeat(ItemStack stack, int amount) { return amount; }
    default int alterHeat(ItemStack stack, IReactor reactor, int x, int y, int amount) {
        return alterHeat(stack, amount);
    }

    default float influenceExplosion(ItemStack stack, IReactor reactor) { return 0; }

    default int getMaxUse() { return 0; }

    default int getUse(ItemStack stack) { return 0; }

    default void incrementUse(ItemStack stack) {}
}
