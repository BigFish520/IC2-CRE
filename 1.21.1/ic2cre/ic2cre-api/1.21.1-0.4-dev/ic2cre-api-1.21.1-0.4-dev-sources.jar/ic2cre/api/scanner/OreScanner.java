package ic2cre.api.scanner;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import java.util.List;
import java.util.Objects;

/** 扫描契约与结果；算法和区块访问由主体负责。 / Scan contract and results; the core owns algorithms and chunk access. */
public final class OreScanner {
    public static final int MAX_RADIUS = 32;
    private static volatile Backend backend;
    private OreScanner() {}

    /** 聚合后的单项结果，物品堆保留准确物品与数据组件。 / Aggregated result preserving exact item components. */
    public record ScanResult(ItemStack stack, int count) {
        public ScanResult {
            Objects.requireNonNull(stack, "stack");
            if (stack.isEmpty() || count <= 0) throw new IllegalArgumentException("Invalid scan result");
            stack = stack.copyWithCount(1);
        }

        @Override public ItemStack stack() { return stack.copy(); }
    }



    public interface Backend {
        List<ScanResult> scanOres(Level level, BlockPos center, int radius);
        boolean isOre(BlockState state);
    }

    public static synchronized void bind(Backend implementation) {
        Objects.requireNonNull(implementation, "implementation");
        if (backend != null && backend != implementation) throw new IllegalStateException("Scanner service already bound");
        backend = implementation;
    }

    public static List<ScanResult> scanOres(Level level, BlockPos center, int radius) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(center, "center");
        if (radius < 0 || radius > MAX_RADIUS) throw new IllegalArgumentException("Invalid scan radius");
        return Objects.requireNonNull(backend, "IC2CRE scanner service is not bound").scanOres(level, center, radius);
    }

    public static boolean isOre(BlockState state) {
        return Objects.requireNonNull(backend, "IC2CRE scanner service is not bound").isOre(state);
    }
}
