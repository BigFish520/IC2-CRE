package ic2cre.api.component;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Defines the stable persistence ID of a {@link Component} subclass.
 * 组件由机器构造函数显式装配，不执行注解扫描或反射实例化。 / Components are assembled explicitly by machine constructors; no annotation scanning or reflective instantiation occurs.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ComponentMeta {
    String id();
}
