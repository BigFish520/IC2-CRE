package ic2cre.api.component;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;


/**
 * 所有机器组件的基类。 / Base class for all machine components.
 * <p>
 * Components encapsulate a single concern (energy, processing, fluid, redstone, upgrades, sound, hover display, etc.).
 * Cross-component access is explicit through {@link ComponentHost#getComponent(Class)}; no reflective wiring occurs.
 * <p>
 * 运行时宿主按照既定 tick 顺序调用生命周期方法。 / Runtime hosts invoke lifecycle methods in their defined tick order.
 */
public abstract class Component {

    protected final ComponentHost host;

    public Component(ComponentHost host) {
        this.host = host;
    }

    // ═══ 生命周期 / Lifecycle ═══

    /** 区块加载或进入世界后调用。 / Called after chunk load or world join. */
    public void onLoad() {}

    /** 方块实体移除或区块卸载时调用。 / Called when the block entity is removed or its chunk unloads. */
    public void onUnload() {}

    /**
     * 组件是否需要逐 tick 更新，默认关闭；需要调用 {@link #onServerTick()} 时重写为 true。
     * Whether this component needs per-tick updates; override with true when {@link #onServerTick()} is required.
     */
    public boolean enableWorldTick() { return false; }

    /** 每个服务端 tick（20 Hz）调用。 / Called every server tick (20 Hz). */
    public void onServerTick() {}

    /** 每个客户端 tick（20 Hz）调用。 / Called every client tick (20 Hz). */
    public void onClientTick() {}

    /** 相邻方块变化时调用。 / Called when a neighboring block changes. */
    public void onNeighborChange(BlockPos neighborPos) {}

    // ═══ 持久化 / Persistence ═══

    /** 将组件状态保存到 NBT。 / Saves component state to NBT. */
    public void save(CompoundTag tag, HolderLookup.Provider registries) {}

    /** 从 NBT 加载组件状态。 / Loads component state from NBT. */
    public void load(CompoundTag tag, HolderLookup.Provider registries) {}

    // ═══ 网络同步 / Network sync ═══

    /** 将同步数据写入数据包缓冲区。 / Writes sync data to a packet buffer. */
    public void writeSync(RegistryFriendlyByteBuf buf) {}

    /** 从数据包缓冲区读取同步数据。 / Reads sync data from a packet buffer. */
    public void readSync(RegistryFriendlyByteBuf buf) {}

    /**
     * 收集网络同步条目；默认不发送数据。 / Collects network sync entries; the default sends nothing.
     *
     * @param out consumer that accepts (key, longValue) pairs
     */
    public void getSyncData(java.util.function.ObjLongConsumer<String> out) {}

    /**
     * 收集包含流体的同步条目，默认委托给仅 long 值的重载。
     * / Collects sync entries containing fluids and delegates to the long-only overload by default.
     */
    public void getSyncData(java.util.function.BiConsumer<String, Long> longOut,
                            java.util.function.BiConsumer<String, net.neoforged.neoforge.fluids.FluidStack> fluidOut) {
        getSyncData(longOut::accept);
    }

    // ═══ 能力 / Capabilities ═══

    /**
     * 声明该组件拥有的能力提供器；方块实体类型仍须在注册配置中显式启用。
     * / Declares capability providers owned by this component; the block-entity type must still opt in explicitly.
     */
    public void registerCapabilities(CapabilityRegistrar registrar) {}




    /** 处理玩家与机器方块的交互。 / Handles player interaction with the machine block. */
    public InteractionResult onUse(Player player, InteractionHand hand) {
        return InteractionResult.PASS;
    }


    public ComponentHost host() { return host; }

    /**
     * 能力提供器注册契约。 / Contract for registering capability providers.
     */
    public interface CapabilityRegistrar {
        <T> void register(
                net.neoforged.neoforge.capabilities.BlockCapability<T, ?> capability,
                T provider
        );

        /**
         * 注册访问规则依赖查询面的提供器。 / Registers a provider whose access rules depend on the queried face.
         */
        <T> void registerSided(
                net.neoforged.neoforge.capabilities.BlockCapability<T, net.minecraft.core.Direction> capability,
                java.util.function.Function<net.minecraft.core.Direction, T> provider
        );
    }
}
