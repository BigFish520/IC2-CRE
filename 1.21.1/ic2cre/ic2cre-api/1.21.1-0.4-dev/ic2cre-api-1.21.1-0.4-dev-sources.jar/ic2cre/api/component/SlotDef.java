package ic2cre.api.component;

import ic2cre.api.energy.EnergyTier;
import ic2cre.api.item.IElectricItem;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.capabilities.Capabilities;

import javax.annotation.Nullable;
import java.util.Set;
import java.util.function.BiPredicate;


public record SlotDef(
        int index,
        SlotRole role,
        Set<TagKey<Item>> acceptTags,
        Set<TagKey<Item>> rejectTags,
        @Nullable EnergyTier maxTier,
        int maxStackSize,
        @Nullable BiPredicate<ItemStack, ItemStack> extraCheck
) {

    public static final int DEFAULT_STACK_SIZE = 64;


    public SlotDef(int index, SlotRole role, Set<TagKey<Item>> acceptTags) {
        this(index, role, acceptTags, Set.of(), null, DEFAULT_STACK_SIZE, null);
    }


    public SlotDef(int index, SlotRole role, Set<TagKey<Item>> acceptTags,
                   Set<TagKey<Item>> rejectTags, @Nullable EnergyTier maxTier,
                   int maxStackSize, @Nullable BiPredicate<ItemStack, ItemStack> extraCheck) {
        this.index = index;
        this.role = role;
        this.acceptTags = acceptTags;
        this.rejectTags = rejectTags;
        this.maxTier = maxTier;
        this.maxStackSize = maxStackSize;
        this.extraCheck = extraCheck;
    }


    public boolean matches(ItemStack stack, ItemStack inSlot) {
        if (stack.isEmpty()) return false;
        if (role == SlotRole.OUTPUT || role == SlotRole.DISPLAY) return false;

        // 即使旧 SlotDef 没有接受标签，也要阻止能源物品进入配方输入；GUI 与路由以 ENERGY 为准。 / Keep energy items out of recipe inputs even without a legacy accept tag; ENERGY is authoritative for GUI and routing.
        if (role == SlotRole.INPUT && stack.is(ic2cre.api.tags.Ic2CreItemTags.BATTERIES)) {
            return false;
        }
        if (role == SlotRole.ENERGY
                && !stack.is(ic2cre.api.tags.Ic2CreItemTags.BATTERIES)
                && !(stack.getItem() instanceof IElectricItem)
                && ic2cre.api.energy.EnergyCapabilityGuard.resolve(
                        () -> stack.getCapability(Capabilities.EnergyStorage.ITEM)) == null) {
            return false;
        }

        if (!rejectTags.isEmpty()) {
            for (var tag : rejectTags) {
                if (stack.is(tag)) return false;
            }
        }

        if (!acceptTags.isEmpty()) {
            boolean matchedTag = false;
            for (var tag : acceptTags) {
                if (stack.is(tag)) { matchedTag = true; break; }
            }
            if (!matchedTag) return false;
        }

        if (maxTier != null && stack.getItem() instanceof IElectricItem ei) {
            if (ei.getEnergyTier() > maxTier.level) return false;
        }

        if (extraCheck != null && !extraCheck.test(stack, inSlot)) return false;

        return true;
    }


    public boolean matches(ItemStack stack) {
        return matches(stack, ItemStack.EMPTY);
    }
}
