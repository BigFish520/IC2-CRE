package ic2cre.api.component;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 组件宿主是方块实体向组件公开的最小运行时契约。
 * / A component host is the minimal runtime contract exposed by a block entity to its components.
 */
public interface ComponentHost extends MachineComponentProvider {

    /**
     * 按类型获取组件。 / Gets a component by type.
     *
     * @param <T>  the component type
     * @param type the component class
     * @return the component instance, or null if not present on this machine
     */
    @Nullable <T extends Component> T getComponent(Class<T> type);

    /** 按构造和注册顺序获取全部组件。 / Gets all components in construction and registration order. */
    Component[] getComponents();

    @Override
    default Component[] getMachineComponents() {
        return getComponents();
    }

    @Override
    @Nullable
    default <T extends Component> T getMachineComponent(Class<T> type) {
        return getComponent(type);
    }

    /** 获取机器物品处理器。 / Gets the machine item handler. */
    @Nullable
    net.neoforged.neoforge.items.IItemHandler getInventory();

    /** 获取所在维度。 / Gets the containing level. */
    Level getLevel();

    /** 获取方块坐标。 / Gets the block position. */
    BlockPos getBlockPos();

    /** 获取当前方块状态。 / Gets the current block state. */
    BlockState getBlockState();

    /** 标记方块实体需要保存。 / Marks the block entity for saving. */
    void markDirty();

    /** 安排下一次服务端 tick；已安排时不重复操作。 / Schedules the next server tick unless already scheduled. */
    void scheduleTick();
}
