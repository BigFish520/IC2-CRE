package ic2cre.api.component;

/**
 * Slot role — defines the semantic purpose of an inventory slot.
 * <p>
 * 由 {@link SlotDef} 声明槽位语义，运行时据此执行槽位副作用。
 * / Used by {@link SlotDef} to declare slot semantics that runtime handlers apply.
 */
public enum SlotRole {

    INPUT,

    OUTPUT,

    ENERGY,

    UPGRADE,

    DISPLAY
}
