package ic2cre.api.component;

import javax.annotation.Nullable;

/**
 * 机器公开已装配组件的轻量契约，不拥有机器逻辑或状态。
 * / Lightweight contract for discovering a machine's assembled components without owning machine logic or state.
 */
public interface MachineComponentProvider {

    /**
     * 返回机器装配的全部组件。 / Returns every component mounted on the machine.
     */
    Component[] getMachineComponents();

    /**
     * 按类型返回一个已装配组件。 / Returns one mounted component by type.
     *
     * @param type component class to look up
     * @return component instance, or null when this machine does not mount it
     */
    @Nullable
    <T extends Component> T getMachineComponent(Class<T> type);
}
