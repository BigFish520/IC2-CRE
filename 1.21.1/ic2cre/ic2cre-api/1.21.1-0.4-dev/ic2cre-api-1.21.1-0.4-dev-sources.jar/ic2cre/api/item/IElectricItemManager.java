package ic2cre.api.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** 所有能量参数与返回量均为 mEU；执行型操作由服务端调用。 / All energy amounts use mEU; executing operations belong on the server. */
public interface IElectricItemManager {
    long charge(ItemStack stack, long amount, int sourceTier, boolean ignoreLimit, boolean simulate);
    long discharge(ItemStack stack, long amount, int sourceTier, boolean ignoreLimit, boolean simulate, boolean internally);
    boolean canUse(ItemStack stack, long amount);
    /** 原子扣能并返回是否成功；负值拒绝，零值不修改状态。 / Atomically consumes energy and reports success; rejects negatives and leaves zero unchanged. */
    boolean use(ItemStack stack, long amount, LivingEntity entity);
    void chargeFromArmor(ItemStack target, LivingEntity entity);
    long getCharge(ItemStack stack);
    long getMaxCharge(ItemStack stack);
    int getTier(ItemStack stack);
}
