package ic2cre.api.item;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** 像 IC2 金属护甲一样导电的装备契约。 / Equipment contract for armor conducting electricity like IC2 metal armor. */
public interface IMetalArmor {
    default boolean isMetalArmor(ItemStack stack, Player player) {
        return true;
    }
}
