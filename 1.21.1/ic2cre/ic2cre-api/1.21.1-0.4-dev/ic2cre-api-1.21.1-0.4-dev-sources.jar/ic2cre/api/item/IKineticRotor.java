package ic2cre.api.item;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * 风力与水力动能发生机使用的 IC2 转子契约。 / IC2 rotor contract used by wind and water kinetic generators.
 */
public interface IKineticRotor {
    /** 返回影响 KU 产出的方块直径。 / Returns the rotor diameter in blocks used for KU production. */
    int getDiameter(ItemStack stack);

    /** 返回转子渲染纹理。 / Returns the rotor render texture. */
    ResourceLocation getRotorRenderTexture(ItemStack stack);

    /** 返回 KU 转换效率。 / Returns the KU conversion efficiency. */
    float getEfficiency(ItemStack stack);

    /** 以 m/s 返回风速下限。 / Returns the minimum wind speed in m/s. */
    double getMinWindSpeed(ItemStack stack);

    /** 以 m/s 返回风速上限。 / Returns the maximum wind speed in m/s. */
    double getMaxWindSpeed(ItemStack stack);

    /** 以 m/s 返回水流速下限。 / Returns the minimum water speed in m/s. */
    default double getMinWaterSpeed(ItemStack stack) {
        return getMinWindSpeed(stack);
    }

    /** 以 m/s 返回水流速上限。 / Returns the maximum water speed in m/s. */
    default double getMaxWaterSpeed(ItemStack stack) {
        return getMaxWindSpeed(stack);
    }

    /** 判断转子是否适用于指定发生机。 / Returns whether the rotor supports the requested generator type. */
    boolean isAcceptedType(ItemStack stack, GearboxType type);

    /** 动能发生机类型。 / Kinetic generator type. */
    enum GearboxType { WATER, WIND }
}
