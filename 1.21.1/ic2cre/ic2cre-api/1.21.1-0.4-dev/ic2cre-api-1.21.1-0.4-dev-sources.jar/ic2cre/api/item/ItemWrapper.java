package ic2cre.api.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

/** 为无法修改自身类的物品提供兼容注册入口。 / Compatibility hooks for items whose own class cannot be modified. */
public final class ItemWrapper {
    private static final Map<Item, List<Predicate<ItemStack>>> BOXABLE_ITEMS = new ConcurrentHashMap<>();

    private ItemWrapper() {}

    public static void registerBoxable(Item item, Predicate<ItemStack> boxable) {
        BOXABLE_ITEMS.computeIfAbsent(Objects.requireNonNull(item, "item"), ignored -> new CopyOnWriteArrayList<>())
                .add(Objects.requireNonNull(boxable, "boxable"));
    }

    public static boolean canBeStoredInToolbox(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        for (Predicate<ItemStack> predicate : BOXABLE_ITEMS.getOrDefault(stack.getItem(), List.of())) {
            if (predicate.test(stack)) return true;
        }
        return stack.getItem() instanceof IBoxable boxable && boxable.canBeStoredInToolbox(stack);
    }
}
