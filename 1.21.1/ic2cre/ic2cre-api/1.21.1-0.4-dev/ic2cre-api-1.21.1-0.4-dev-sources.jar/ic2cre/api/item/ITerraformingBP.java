package ic2cre.api.item;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Defines the energy cost, radius, and operation for a terraforming blueprint. / 定义地形改造蓝图的能耗、范围和执行操作。
 * <p>
 */
public interface ITerraformingBP {

    /**
     * 获取每 tick 消耗的 EU。
     */
    double getConsume(ItemStack stack);


    int getRange(ItemStack stack);


    default boolean canInsert(ItemStack stack, Player player, Level level, BlockPos pos) {
        return true;
    }

    /**
     * 执行一次地形改造操作。
     *
     * @param level 世界
     * @param pos   Terraformer 所在位置
     * @return true 如果执行了有效操作
     */
    boolean terraform(ItemStack stack, Level level, BlockPos pos);
}
