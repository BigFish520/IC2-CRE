package ic2cre.api.item;

import ic2cre.api.energy.EnergyTier;

/**
 * 使用同步 DataComponent 保存 mEU 的物品契约。 / Item contract storing mEU through synchronized data components.
 */
public interface IElectricItem {

    /**
     * 返回物品可存储的最大 mEU。 / Returns the maximum mEU stored by the item.
     */
    long getMaxCharge();

    /**
     * 返回决定安全输入输出速率的能源等级。 / Returns the energy tier controlling safe transfer rates.
     *
     * @return 等级数值 / tier level matching {@link EnergyTier#level}
     */
    int getEnergyTier();

    /**
     * Whether this item can provide energy to other items (like batteries) / 该物品能否向其他物品提供能量（如电池）
     * <p>
     * Returns {@code true} for batteries and energy crystals; {@code false} for tools.
     * 电池和能量水晶返回 {@code true}；工具返回 {@code false}。
     */
    default boolean canProvideEnergy() {
        return false;
    }

    /**
     * Whether this item can accept charge from external sources / 该物品能否从外部源接收充电
     * <p>
     * Returns {@code true} for rechargeable batteries/tools; {@code false} for disposable batteries.
     * 可充电电池/工具返回 {@code true}；一次性电池返回 {@code false}。
     */
    default boolean canCharge() {
        return true;
    }
}
