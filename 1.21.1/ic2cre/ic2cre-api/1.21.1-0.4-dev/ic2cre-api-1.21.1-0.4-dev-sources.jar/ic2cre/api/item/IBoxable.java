package ic2cre.api.item;

import net.minecraft.world.item.ItemStack;

/** 声明物品栈可存入 IC2 工具箱。 / Declares that an item stack may be stored in an IC2 toolbox. */
public interface IBoxable {
    boolean canBeStoredInToolbox(ItemStack stack);
}
