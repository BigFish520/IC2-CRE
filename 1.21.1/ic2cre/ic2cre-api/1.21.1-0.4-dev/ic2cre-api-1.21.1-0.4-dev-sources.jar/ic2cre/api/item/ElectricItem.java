package ic2cre.api.item;

import java.util.Objects;

/** 主体绑定的电力物品服务，不加载实现类。 / Runtime-bound electric item service without implementation class loading. */
public final class ElectricItem {
    private static volatile IElectricItemManager manager;

    private ElectricItem() {}

    public static IElectricItemManager getManager() {
        return Objects.requireNonNull(manager, "IC2CRE electric item service is not bound");
    }

    public static synchronized void bind(IElectricItemManager implementation) {
        Objects.requireNonNull(implementation, "implementation");
        if (manager != null && manager != implementation) {
            throw new IllegalStateException("IC2CRE electric item service is already bound");
        }
        manager = implementation;
    }
}
