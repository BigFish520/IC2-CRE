package ic2cre.api.item;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Defines drill timing, energy use, and harvest behavior for mining machines. / 定义采矿机钻头的用时、能耗和收获行为。
 * <p>
 * 实现此接口的物品可作为采矿机钻头使用，定义挖掘速度、能耗和收获成本。
 */
public interface IMiningDrill {

    /**
     * 获取挖掘一个方块所需的基础 tick 数。
     * 普通钻头=200, 钻石钻头=50, 铱钻头=20。
     */
    int getBreakTime();

    /**
     * 获取挖掘时每 tick 消耗的 EU。
     * 普通钻头=6, 钻石钻头=20, 铱钻头=200。
     */
    int getEnergyUse();


    int getHarvestLevelCost();

    /**
     * Performs drill-specific pre-harvest logic. 自定义钻头可在此执行耐久、能源或特殊破坏逻辑。
     * / Custom drills may apply durability, energy, or special breaking rules here.
     */
    default boolean breakBlock(ItemStack stack, Level level, BlockPos target, BlockState state) {
        return true;
    }
}
