package ic2cre.api.item;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** 为完整防化保护提供能力的装备契约。 / Equipment contract contributing to complete hazmat protection. */
public interface IHazmatLike {
    boolean addsProtection(LivingEntity entity, EquipmentSlot slot, ItemStack stack);

    default boolean fullyProtects(LivingEntity entity, EquipmentSlot slot, ItemStack stack) {
        return false;
    }
}
