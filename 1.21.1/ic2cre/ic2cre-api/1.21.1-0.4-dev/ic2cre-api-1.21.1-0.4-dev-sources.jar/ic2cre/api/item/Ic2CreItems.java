package ic2cre.api.item;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/** 注册完成后按物品 ID 查询；未知 ID 返回空栈，不暴露注册实现。 / Resolves item IDs after registration; unknown IDs return empty stacks without exposing registry implementation. */
public final class Ic2CreItems {
    private Ic2CreItems() {}
    public static ItemStack getItem(String path) {
        return getItem(Ic2CreAPI.resource(path));
    }
    public static ItemStack getItem(ResourceLocation id) {
        return BuiltInRegistries.ITEM.getOptional(id).map(ItemStack::new).orElse(ItemStack.EMPTY);
    }
}
