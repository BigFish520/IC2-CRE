package ic2cre.api.damage;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.level.Level;

/** 提供 IC2 辐射伤害类型及其判定。 / Provides the IC2 radiation damage source and its predicate. */
public final class RadiationDamageSources {
    public static final ResourceKey<DamageType> RADIATION = ResourceKey.create(
            Registries.DAMAGE_TYPE, Ic2CreAPI.resource("radiation"));

    private RadiationDamageSources() {}

    public static DamageSource radiation(Level level) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(RADIATION));
    }

    public static boolean isRadiation(DamageSource source) {
        return source != null && source.typeHolder().unwrapKey().map(RADIATION::equals).orElse(false);
    }
}
