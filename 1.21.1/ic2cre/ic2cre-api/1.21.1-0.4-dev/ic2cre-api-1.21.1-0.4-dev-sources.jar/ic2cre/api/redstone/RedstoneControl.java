package ic2cre.api.redstone;

/** 机器组件公开的只读红石输入与控制视图。 / Read-only redstone input/control view exposed by a machine component. */
public interface RedstoneControl {
    /** 本地世界输入，范围 0–15。 / Local world input in the range 0–15. */
    int getRawSignal();
    /** 汇总并应用修饰后的输入，范围 0–15。 / Aggregated and modified input in the range 0–15. */
    int getSignal();
    /** 有效输入是否非零，不代表机器正在加工。 / Whether effective input is nonzero, not whether the machine is processing. */
    boolean isEnabled();
    boolean isInverted();
}
