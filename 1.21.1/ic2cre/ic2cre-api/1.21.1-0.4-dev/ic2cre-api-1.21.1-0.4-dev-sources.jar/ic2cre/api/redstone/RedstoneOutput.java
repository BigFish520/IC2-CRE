package ic2cre.api.redstone;

/** 机器组件公开的红石输出视图；信号范围为 0–15。 / Machine redstone output view; signals range from 0 to 15. */
public interface RedstoneOutput {
    int getSignal();
}
