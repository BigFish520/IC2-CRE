package ic2cre.api.redstone;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.Direction;
import net.neoforged.neoforge.capabilities.BlockCapability;

/** IC2:CRE 机器公开的红石输入与输出能力。 / Public redstone input/output capabilities for IC2:CRE machines. */
public final class RedstoneCapabilities {
    private RedstoneCapabilities() {}

    public static final BlockCapability<RedstoneControl, Direction> CONTROL_BLOCK =
            BlockCapability.createSided(Ic2CreAPI.resource("redstone_control"), RedstoneControl.class);

    public static final BlockCapability<RedstoneOutput, Direction> OUTPUT_BLOCK =
            BlockCapability.createSided(Ic2CreAPI.resource("redstone_output"), RedstoneOutput.class);
}
