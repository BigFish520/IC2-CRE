package ic2cre.api.block;

import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;

/**
 * 转子提供者接口 — 供 BER 获取转子渲染数据。
 * <p>
 * 实现者：WindKineticSourceBE
 */
public interface IRotorProvider {


    int getRotorDiameter();

    /** 当前旋转角度（度），仅供客户端 BER 获取视觉状态。 */
    float getRotorAngle();

    /**
     * 获取当前帧转子角度。
     *
     * <p>实现可以使用 {@code partialTick} 做帧间插值，但不得让该值参与
     * 服务端机器逻辑、KU 产出或转子损耗计算。</p>
     */
    default float getRotorAngle(float partialTick) {
        return getRotorAngle();
    }


    ResourceLocation getRotorRenderTexture();


    Direction getFacing();


    float getRotorSpeed();
}
