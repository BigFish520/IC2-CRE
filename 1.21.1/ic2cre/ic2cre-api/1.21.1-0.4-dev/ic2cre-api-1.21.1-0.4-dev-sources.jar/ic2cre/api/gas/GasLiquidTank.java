package ic2cre.api.gas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.common.util.INBTSerializable;


/**
 * 气液储罐一次只保存气体或流体。 / A gas-liquid tank stores either gas or fluid, never both at once.
 */
public class GasLiquidTank implements INBTSerializable<CompoundTag> {

    private final GasTank gasTank;
    private final FluidTank fluidTank;
    private Type currentType = Type.EMPTY;
    private boolean suppressNotifications;

    public enum Type { EMPTY, GAS, FLUID }

    public GasLiquidTank(int gasCapacity, int fluidCapacity) {
        this.gasTank = new GasTank(gasCapacity) {
            @Override protected void onContentsChanged() {
                updateType();
                if (!suppressNotifications) GasLiquidTank.this.onContentsChanged();
            }
        };
        this.fluidTank = new FluidTank(fluidCapacity) {
            @Override protected void onContentsChanged() {
                updateType();
                if (!suppressNotifications) GasLiquidTank.this.onContentsChanged();
            }
        };
    }

    public GasLiquidTank(int capacity) {
        this(capacity, capacity);
    }

    private void updateType() {
        if (!gasTank.isEmpty()) currentType = Type.GAS;
        else if (!fluidTank.isEmpty()) currentType = Type.FLUID;
        else currentType = Type.EMPTY;
    }

    public Type getType() { return currentType; }
    public GasTank getGasTank() { return gasTank; }
    public FluidTank getFluidTank() { return fluidTank; }

    public boolean isEmpty() { return currentType == Type.EMPTY; }
    public int getCapacity() { return Math.max(gasTank.getCapacity(), fluidTank.getCapacity()); }

    /** 注入气体并返回实际接收量。 / Fills gas and returns the accepted amount. */
    public int fillGas(GasStack stack, boolean simulate) {
        if (!fluidTank.isEmpty()) return 0;
        return gasTank.fill(stack, simulate);
    }

    /** 注入流体并返回实际接收量。 / Fills fluid and returns the accepted amount. */
    public int fillFluid(FluidStack stack, boolean simulate) {
        if (!gasTank.isEmpty()) return 0;
        return fluidTank.fill(stack, simulate ? IFluidHandler.FluidAction.SIMULATE : IFluidHandler.FluidAction.EXECUTE);
    }

    /** 排出气体。 / Drains gas. */
    public GasStack drainGas(int maxAmount, boolean simulate) {
        return gasTank.drain(maxAmount, simulate);
    }

    /** 排出流体。 / Drains fluid. */
    public FluidStack drainFluid(int maxAmount, boolean simulate) {
        return fluidTank.drain(maxAmount, simulate ? IFluidHandler.FluidAction.SIMULATE : IFluidHandler.FluidAction.EXECUTE);
    }

    /** 清空两种内容并发送一次变更通知。 / Clears both contents and emits one change notification. */
    public void clear() {
        if (isEmpty()) return;
        suppressNotifications = true;
        try {
            gasTank.setGas(GasStack.EMPTY);
            fluidTank.setFluid(FluidStack.EMPTY);
            currentType = Type.EMPTY;
        } finally {
            suppressNotifications = false;
        }
        onContentsChanged();
    }

    protected void onContentsChanged() {}

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        tag.putString("type", currentType.name());
        if (currentType == Type.GAS) {
            tag.put("gas", gasTank.serializeNBT(registries));
        } else if (currentType == Type.FLUID) {
            tag.put("fluid", fluidTank.writeToNBT(registries, new CompoundTag()));
        }
        return tag;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider registries, CompoundTag tag) {
        suppressNotifications = true;
        try {
            gasTank.setGas(GasStack.EMPTY);
            fluidTank.setFluid(FluidStack.EMPTY);
            String type = tag.getString("type");
            if ("GAS".equals(type) && tag.contains("gas")) {
                gasTank.deserializeNBT(registries, tag.getCompound("gas"));
            } else if ("FLUID".equals(type) && tag.contains("fluid")) {
                fluidTank.readFromNBT(registries, tag.getCompound("fluid"));
            }
            updateType();
        } finally {
            suppressNotifications = false;
        }
    }
}
