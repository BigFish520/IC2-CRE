package ic2cre.api.gas;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * 气体类型及其 mL 数量。 / Gas type and amount measured in mL.
 */
public class GasStack {

    public static final Codec<GasStack> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Gas.CODEC.fieldOf("gas").forGetter(GasStack::getGas),
            Codec.intRange(1, Integer.MAX_VALUE).fieldOf("amount").forGetter(GasStack::getAmount)
    ).apply(instance, GasStack::new));
    public static final StreamCodec<RegistryFriendlyByteBuf, GasStack> STREAM_CODEC = StreamCodec.composite(
            Gas.STREAM_CODEC, GasStack::getGas,
            ByteBufCodecs.VAR_INT, GasStack::getAmount,
            GasStack::new);

    private final Gas gas;
    private int amount;

    public GasStack(Gas gas, int amount) {
        if (gas == null) throw new IllegalArgumentException("Gas must not be null");
        this.gas = gas;
        this.amount = Math.max(0, amount);
    }

    public Gas getGas() { return gas; }
    public int getAmount() { return amount; }
    public void setAmount(int amount) { this.amount = Math.max(0, amount); }
    public void grow(int delta) {
        if (delta < 0) throw new IllegalArgumentException("Gas growth must not be negative");
        this.amount = (int) Math.min(Integer.MAX_VALUE, (long) amount + delta);
    }
    public void shrink(int delta) {
        if (delta < 0) throw new IllegalArgumentException("Gas drain must not be negative");
        this.amount = Math.max(0, amount - delta);
    }

    public boolean isEmpty() { return amount <= 0; }
    public GasStack copy() { return new GasStack(gas, amount); }

    private static final net.minecraft.resources.ResourceLocation EMPTY_TEXTURE =
            net.minecraft.resources.ResourceLocation.withDefaultNamespace("block/water_still");
    public static final GasStack EMPTY = new GasStack(new Gas(
            0, 300, false, EMPTY_TEXTURE, EMPTY_TEXTURE), 0) {
        @Override public boolean isEmpty() { return true; }
        @Override public int getAmount() { return 0; }
        @Override public void setAmount(int amount) {}
        @Override public void grow(int delta) {}
        @Override public void shrink(int delta) {}
        @Override public GasStack copy() { return EMPTY; }
    };

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GasStack gs)) return false;
        return amount == gs.amount && gas.equals(gs.gas);
    }

    @Override
    public int hashCode() { return 31 * gas.hashCode() + amount; }

    @Override
    public String toString() { return amount + " mL of " + gas.getId(); }
}
