package ic2cre.api.gas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;

/**
 * 带标准 NBT 序列化的有界气体储罐。 / Bounded gas tank with standard NBT serialization.
 */
public class GasTank implements IGasHandler, INBTSerializable<CompoundTag> {

    private GasStack gas = GasStack.EMPTY;
    private final int capacity;

    public GasTank(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("Gas tank capacity must be positive");
        this.capacity = capacity;
    }

    @Override
    public GasStack drain(int maxAmount, boolean simulate) {
        if (maxAmount <= 0 || gas.isEmpty()) return GasStack.EMPTY;
        int toDrain = Math.min(maxAmount, gas.getAmount());
        GasStack result = new GasStack(gas.getGas(), toDrain);
        if (!simulate) {
            gas.shrink(toDrain);
            if (gas.isEmpty()) gas = GasStack.EMPTY;
            onContentsChanged();
        }
        return result;
    }

    @Override
    public int fill(GasStack stack, boolean simulate) {
        if (stack == null || stack.isEmpty() || stack.getAmount() <= 0) return 0;
        if (!gas.isEmpty() && !gas.getGas().equals(stack.getGas())) return 0;
        int space = capacity - gas.getAmount();
        int toFill = Math.min(space, stack.getAmount());
        if (toFill <= 0) return 0;
        if (!simulate) {
            if (gas.isEmpty()) {
                gas = new GasStack(stack.getGas(), toFill);
            } else {
                gas.grow(toFill);
            }
            onContentsChanged();
        }
        return toFill;
    }

    @Override
    public GasStack getGas() { return gas.isEmpty() ? GasStack.EMPTY : gas.copy(); }
    @Override
    public int getCapacity() { return capacity; }

    public boolean isEmpty() { return gas.isEmpty(); }
    public boolean isFull() { return gas.getAmount() >= capacity; }
    public int getAmount() { return gas.getAmount(); }

    /** 设置直接内容并约束到容量。 / Sets contents directly and clamps them to capacity. */
    public void setGas(GasStack stack) {
        this.gas = stack != null && !stack.isEmpty()
                ? new GasStack(stack.getGas(), Math.min(capacity, stack.getAmount())) : GasStack.EMPTY;
        onContentsChanged();
    }

    protected void onContentsChanged() {}

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        if (!gas.isEmpty()) {
            tag.putString("gas", gas.getGas().getId().toString());
            tag.putInt("amount", gas.getAmount());
        }
        return tag;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider registries, CompoundTag tag) {
        if (tag.contains("gas")) {
            String id = tag.getString("gas");
            int amount = tag.getInt("amount");
            var gasType = ic2cre.api.gas.GasRegistry.get(id);
            if (gasType != null && amount > 0) {
                gas = new GasStack(gasType, Math.min(capacity, amount));
                return;
            }
        }
        gas = GasStack.EMPTY;
    }
}
