package ic2cre.api.gas;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.Direction;

/** IC2 气体能力键。 / IC2 gas capability keys. */
public final class Ic2CreGasCapabilities {

    private Ic2CreGasCapabilities() {}

    /** 物品气体处理器。 / Item gas handler. */
    public static final net.neoforged.neoforge.capabilities.ItemCapability<IGasHandler, Void> GAS_HANDLER_ITEM =
            net.neoforged.neoforge.capabilities.ItemCapability.createVoid(
                    Ic2CreAPI.resource("gas_handler"), IGasHandler.class);

    /** 方块气体处理器。 / Block gas handler. */
    public static final net.neoforged.neoforge.capabilities.BlockCapability<IGasHandler, Direction> GAS_HANDLER_BLOCK =
            net.neoforged.neoforge.capabilities.BlockCapability.createSided(
                    Ic2CreAPI.resource("gas_handler"), IGasHandler.class);
}
