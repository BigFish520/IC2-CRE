package ic2cre.api.gas;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;

/**
 * 独立于 NeoForge Fluid 的气态物质定义。 / Gaseous substance definition independent of NeoForge fluids.
 */
public final class Gas {

    public static final Codec<Gas> CODEC = ResourceLocation.CODEC.comapFlatMap(
            id -> {
                Gas gas = GasRegistry.get(id);
                return gas == null ? DataResult.error(() -> "Unknown gas: " + id) : DataResult.success(gas);
            },
            Gas::getId);
    public static final StreamCodec<RegistryFriendlyByteBuf, Gas> STREAM_CODEC =
            ByteBufCodecs.registry(GasRegistry.KEY);

    private final int tint;
    private final int temperature;
    private final boolean isHot;
    private final ResourceLocation stillTexture;
    private final ResourceLocation flowingTexture;

    public Gas(int tint, int temperature, boolean isHot,
               ResourceLocation stillTexture, ResourceLocation flowingTexture) {
        if (temperature < 0) throw new IllegalArgumentException("temperature must not be negative");
        this.tint = tint;
        this.temperature = temperature;
        this.isHot = isHot;
        this.stillTexture = java.util.Objects.requireNonNull(stillTexture, "stillTexture");
        this.flowingTexture = java.util.Objects.requireNonNull(flowingTexture, "flowingTexture");
    }

    public ResourceLocation getId() {
        return java.util.Objects.requireNonNull(GasRegistry.registry().getKey(this), "Unregistered gas");
    }
    public int getTint() { return tint; }
    public int getTemperature() { return temperature; }
    public boolean isHot() { return isHot; }
    public ResourceLocation getStillTexture() { return stillTexture; }
    public ResourceLocation getFlowingTexture() { return flowingTexture; }
    public int getRgb() { return tint & 0x00FFFFFF; }

    @Override
    public String toString() { return "Gas[" + getId() + "]"; }
}
