package ic2cre.api.gas;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

import java.util.Collection;
import java.util.Objects;

/**
 * 支持跨模组定义的同步气体注册表。 / Synchronized gas registry supporting cross-mod definitions.
 */
public final class GasRegistry {

    public static final ResourceKey<Registry<Gas>> KEY = ResourceKey.createRegistryKey(
            ResourceLocation.fromNamespaceAndPath("ic2cre", "gas"));

    private GasRegistry() {}

    @SuppressWarnings("unchecked")
    public static Registry<Gas> registry() {
        return (Registry<Gas>) Objects.requireNonNull(
                BuiltInRegistries.REGISTRY.get(KEY.location()), "Gas registry is not available yet");
    }

    /**
     * 按 ID 查询气体。 / Looks up a gas by ID.
     */
    public static Gas get(ResourceLocation id) {
        return registry().get(id);
    }

    /**
     * 按命名空间 ID 字符串查询气体。 / Looks up a gas by namespaced ID string.
     */
    public static Gas get(String id) {
        ResourceLocation parsed = ResourceLocation.tryParse(id);
        return parsed == null ? null : get(parsed);
    }

    /**
     * 获取已注册气体的不可修改快照。 / Returns an immutable snapshot of registered gases.
     */
    public static Collection<Gas> getAllGases() {
        return registry().stream().toList();
    }
}
