package ic2cre.api.gas;

/**
 * 通过 NeoForge Capability 暴露的气体处理器。 / Gas handler exposed through NeoForge capabilities.
 */
public interface IGasHandler {

    /** 排出气体并返回实际排出堆。 / Drains and returns the extracted gas stack. */
    GasStack drain(int maxAmount, boolean simulate);

    /** 注入气体并返回实际接收量。 / Fills gas and returns the accepted amount. */
    int fill(GasStack stack, boolean simulate);

    /** 获取当前气体的只读快照（无气体返回 GasStack.EMPTY）。 / Returns a snapshot of the current gas, or GasStack.EMPTY. */
    GasStack getGas();

    /** 获取最大容量（mL）。 / Returns the maximum capacity in mL. */
    int getCapacity();

    /** 获取当前气体量。 / Returns the current gas amount. */
    default int getAmount() { return getGas().getAmount(); }

    /** 返回处理器是否为空。 / Returns whether the handler is empty. */
    default boolean isEmpty() { return getGas().isEmpty(); }

    /** 返回处理器是否已满。 / Returns whether the handler is full. */
    default boolean isFull() { return getAmount() >= getCapacity(); }
}
