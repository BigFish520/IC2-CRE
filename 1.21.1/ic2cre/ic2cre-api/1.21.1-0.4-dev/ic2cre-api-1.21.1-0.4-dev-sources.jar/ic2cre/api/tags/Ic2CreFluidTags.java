package ic2cre.api.tags;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;

/**
 * IC2 流体标签；外部模组可通过数据包扩展兼容流体。 / IC2 fluid tags extensible by external datapacks.
 */
public final class Ic2CreFluidTags {


    public static final TagKey<Fluid> FLUID_HEAT_BIOMASS = create("fluid_heat/biomass");

    public static final TagKey<Fluid> FLUID_HEAT_BIOGAS = create("fluid_heat/biogas");
    /** 流体热量发电机燃料：残渣（BuildCraft，10 mB → 6 HU/t） */
    public static final TagKey<Fluid> FLUID_HEAT_RESIDUE = create("fluid_heat/residue");

    public static final TagKey<Fluid> FLUID_HEAT_OIL = create("fluid_heat/oil");
    /** 流体热量发电机燃料：气态燃料（BuildCraft，10 mB → 90 HU/t） */
    public static final TagKey<Fluid> FLUID_HEAT_GASEOUS = create("fluid_heat/gaseous");

    public static final TagKey<Fluid> FLUID_HEAT_FUEL = create("fluid_heat/fuel");

    public static final TagKey<Fluid> FLUID_HEAT_BIOETHANOL = create("fluid_heat/bioethanol");

    /** 半流质发电机兼容标签。 / Semifluid generator compatibility tags. */
    public static final TagKey<Fluid> SEMIFLUID_BIOMASS = create("semifluid_generator/biomass");
    public static final TagKey<Fluid> SEMIFLUID_HYDROGEN = create("semifluid_generator/hydrogen");
    public static final TagKey<Fluid> SEMIFLUID_CHLORINE = create("semifluid_generator/chlorine");
    public static final TagKey<Fluid> SEMIFLUID_CREOSOTE = create("semifluid_generator/creosote");

    private static TagKey<Fluid> create(String name) {
        return TagKey.create(Registries.FLUID, ResourceLocation.fromNamespaceAndPath(Ic2CreAPI.MOD_ID, name));
    }
}
