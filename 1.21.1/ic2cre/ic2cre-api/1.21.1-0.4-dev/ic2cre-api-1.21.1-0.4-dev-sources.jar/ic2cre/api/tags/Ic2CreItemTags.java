package ic2cre.api.tags;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

/**
 * 用于数据驱动归类的 IC2 物品标签。 / IC2 item tags for data-driven classification.
 */
public final class Ic2CreItemTags {

    private Ic2CreItemTags() {}

    /**
     * 电池标签 — 标记可作为机器供能槽放电的物品。
     * <p>
     * 其他模组可通过 datapack 将自己的能量物品加入此标签以兼容 IC2 供能槽。
     * 供能槽检查：{@code stack.is(Ic2CreItemTags.BATTERIES)} + 电压等级判定。
     */
    public static final TagKey<Item> BATTERIES = create("batteries");
    public static final TagKey<Item> RECYCLER_BLACKLIST = create("recycler_blacklist");
    public static final TagKey<Item> RECYCLER_WHITELIST = create("recycler_whitelist");

    /** 通用材料标签：兼容外部模组的基础与高级电路板。 / Common circuit material tags for mod interoperability. */
    public static final TagKey<Item> CIRCUITS_BASIC = common("circuits/basic");
    public static final TagKey<Item> CIRCUITS_ADVANCED = common("circuits/advanced");
    public static final TagKey<Item> CHESTS_WOODEN = common("chests/wooden");

    /** 通用锭标签。 / Common ingot tags. */
    public static final TagKey<Item> INGOTS_BRONZE = common("ingots/bronze");
    public static final TagKey<Item> INGOTS_COPPER = common("ingots/copper");
    public static final TagKey<Item> INGOTS_GOLD = common("ingots/gold");
    public static final TagKey<Item> INGOTS_IRON = common("ingots/iron");
    public static final TagKey<Item> INGOTS_LEAD = common("ingots/lead");
    public static final TagKey<Item> INGOTS_SILVER = common("ingots/silver");
    public static final TagKey<Item> INGOTS_STEEL = common("ingots/steel");
    public static final TagKey<Item> INGOTS_TIN = common("ingots/tin");
    public static final TagKey<Item> INGOTS_URANIUM = common("ingots/uranium");

    /** 通用粉末标签。 / Common dust tags. */
    public static final TagKey<Item> DUSTS_BRONZE = common("dusts/bronze");
    public static final TagKey<Item> DUSTS_DIAMOND = common("dusts/diamond");
    public static final TagKey<Item> DUSTS_ENERGIUM = common("dusts/energium");
    public static final TagKey<Item> DUSTS_COPPER = common("dusts/copper");
    public static final TagKey<Item> DUSTS_COAL = common("dusts/coal");
    public static final TagKey<Item> DUSTS_GOLD = common("dusts/gold");
    public static final TagKey<Item> DUSTS_IRON = common("dusts/iron");
    public static final TagKey<Item> DUSTS_LAPIS = common("dusts/lapis");
    public static final TagKey<Item> DUSTS_LEAD = common("dusts/lead");
    public static final TagKey<Item> DUSTS_LITHIUM = common("dusts/lithium");
    public static final TagKey<Item> DUSTS_OBSIDIAN = common("dusts/obsidian");
    public static final TagKey<Item> DUSTS_SILVER = common("dusts/silver");
    public static final TagKey<Item> DUSTS_SILICON_DIOXIDE = common("dusts/silicon_dioxide");
    public static final TagKey<Item> DUSTS_STONE = common("dusts/stone");
    public static final TagKey<Item> DUSTS_SULFUR = common("dusts/sulfur");
    public static final TagKey<Item> DUSTS_TIN = common("dusts/tin");

    /** 供 IC2 配方与外部模组互通的通用金属板标签。 / Common plate tags for recipe interoperability. */
    public static final TagKey<Item> PLATES_IRON = common("plates/iron");
    public static final TagKey<Item> PLATES_STEEL = common("plates/steel");
    public static final TagKey<Item> PLATES_BRONZE = common("plates/bronze");
    public static final TagKey<Item> PLATES_COPPER = common("plates/copper");
    public static final TagKey<Item> PLATES_GOLD = common("plates/gold");
    public static final TagKey<Item> PLATES_LEAD = common("plates/lead");
    public static final TagKey<Item> PLATES_TIN = common("plates/tin");

    private static TagKey<Item> create(String name) {
        return TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(Ic2CreAPI.MOD_ID, name));
    }

    private static TagKey<Item> common(String name) {
        return TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath("c", name));
    }
}
