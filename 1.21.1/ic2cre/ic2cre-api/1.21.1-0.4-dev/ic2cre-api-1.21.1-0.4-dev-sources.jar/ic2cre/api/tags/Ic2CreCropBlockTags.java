package ic2cre.api.tags;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

/** 金属作物使用的根系方块标签，外部模组可通过数据包扩展。 / Root-block tags for metal crops, extensible by datapacks. */
public final class Ic2CreCropBlockTags {
    private Ic2CreCropBlockTags() {}

    public static final TagKey<Block> FERRU_ROOT = create("crop_roots/ferru");
    public static final TagKey<Block> CYPRIUM_ROOT = create("crop_roots/cyprium");
    public static final TagKey<Block> STAGNIUM_ROOT = create("crop_roots/stagnium");
    public static final TagKey<Block> PLUMBISCUS_ROOT = create("crop_roots/plumbiscus");
    public static final TagKey<Block> AURELIA_ROOT = create("crop_roots/aurelia");
    public static final TagKey<Block> SHINING_ROOT = create("crop_roots/shining");

    private static TagKey<Block> create(String name) {
        return TagKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath(Ic2CreAPI.MOD_ID, name));
    }
}
