package ic2cre.api.kinetic;

/** 服务端确认并同步给机器 GUI 的运行状态。 / Server-authoritative status synchronized to the machine GUI. */
public enum KineticMachineStatus {
    NO_ROTOR(0),
    RUNNING(1),
    LOW_INPUT(2),
    ROTOR_INTRUSION(3),
    INVALID_ENVIRONMENT(4);

    private final int id;

    KineticMachineStatus(int id) {
        this.id = id;
    }

    public int id() {
        return id;
    }
}
