package ic2cre.api.kinetic;

import net.minecraft.core.Direction;

/** IC2:CRE 动能方块实体公开的 KU 处理器。 / Public KU handler exposed by IC2:CRE kinetic block entities. */
public interface KineticHandler {
    long drainKineticEnergy(long maxAmount);
    /** 返回指定方向当前可抽取的 KU，不改变动能源状态。 / Returns KU currently available from this side without mutating the source. */
    default long getAvailableKineticEnergy(Direction side) {
        return canOutputKineticTo(side) ? Math.max(0L, getKineticEnergy()) : 0L;
    }
    long getKineticEnergy();
    long getMaxKineticEnergy();

    default boolean canOutputKineticTo(Direction side) { return true; }
}
