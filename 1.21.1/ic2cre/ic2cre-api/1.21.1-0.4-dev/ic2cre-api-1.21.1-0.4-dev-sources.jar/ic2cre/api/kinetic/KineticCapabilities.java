package ic2cre.api.kinetic;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.Direction;
import net.neoforged.neoforge.capabilities.BlockCapability;

/** 提供或消耗 KU 的机器所使用的 NeoForge 方块能力。 / NeoForge block capability for machines that provide or consume KU. */
public final class KineticCapabilities {
    private KineticCapabilities() {}

    public static final BlockCapability<KineticHandler, Direction> KINETIC_HANDLER_BLOCK =
            BlockCapability.createSided(Ic2CreAPI.resource("kinetic_handler"), KineticHandler.class);
}
