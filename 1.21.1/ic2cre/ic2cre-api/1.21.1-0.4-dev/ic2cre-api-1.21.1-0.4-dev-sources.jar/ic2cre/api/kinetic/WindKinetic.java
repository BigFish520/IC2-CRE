package ic2cre.api.kinetic;

/**
 * 风场提供给风力动能发生机的实际风速值。
 *
 * <p>该类型只表示风速，不包含转子效率、尾流衰减或 KU 换算结果。
 * GUI、外部设备和机器逻辑应通过 {@link #speed()} 或 {@link #value()} 读取数值。</p>
 */
public record WindKinetic(double speed) {

    public static final WindKinetic ZERO = new WindKinetic(0.0D);

    public WindKinetic {
        if (!Double.isFinite(speed)) speed = 0.0D;
        speed = Math.max(0.0D, speed);
    }

    /** 数值提取别名，便于 GUI 和外部调用者读取实际风速。 / Value alias for GUIs and external callers. */
    public double value() {
        return speed;
    }

}
