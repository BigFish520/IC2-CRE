package ic2cre.api.recipe;

import java.util.Locale;

/**
 * 机器处理类型，是机器组件与集成使用的稳定配方类别标识。 / Stable recipe category used by machine components and integrations.
 */
public enum ProcessType {
    MACERATOR,
    EXTRACTOR,
    COMPRESSOR,
    FURNACE,
    RECYCLER,
    METAL_FORMER,
    CANNER,
    ORE_WASHING,
    THERMAL_CENTRIFUGE,
    BLOCK_CUTTER,
    BLAST_FURNACE,
    FERMENTER,
    INDUCTION,
    FLUID_BOTTLER,
    MAGNETIZER,
    FLUID_HEAT,
    SEMIFLUID_FUEL,
    NONE;

    public String getPath() {
        return "machine/" + name().toLowerCase(Locale.ROOT);
    }
}
