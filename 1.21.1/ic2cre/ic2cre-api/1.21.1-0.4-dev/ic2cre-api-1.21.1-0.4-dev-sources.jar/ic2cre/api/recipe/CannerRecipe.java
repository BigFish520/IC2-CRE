package ic2cre.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.function.Supplier;
import java.util.Objects;

/** 固体装罐、流体填充、排空与物品混合操作的统一原生配方。 / Unified native recipe for solid canning, fluid filling, draining, and item mixing. */
public final class CannerRecipe implements Recipe<CannerRecipeInput> {
    public enum Mode { SOLID, FILL, DRAIN, MIX_ITEM }

    private final Mode mode;
    private final Ingredient container;
    private final int containerCount;
    private final Ingredient additive;
    private final int additiveCount;
    private final FluidStack primaryFluid;
    private final FluidStack secondaryFluid;
    private final ItemStack resultItem;
    private final FluidStack resultFluid;
    private final ItemStack returnedContainer;
    private final int processingTicks;
    private final long energyPerTickMeu;
    private final long totalEnergyMeu;
    private final Supplier<? extends RecipeType<?>> type;
    private final Supplier<? extends RecipeSerializer<?>> serializer;

    public CannerRecipe(Mode mode, Ingredient container, int containerCount,
                        Ingredient additive, int additiveCount, FluidStack primaryFluid,
                        FluidStack secondaryFluid, ItemStack resultItem, FluidStack resultFluid,
                        ItemStack returnedContainer, int processingTicks, long energyPerTickMeu,
                        long totalEnergyMeu,
                        Supplier<? extends RecipeType<?>> type,
                        Supplier<? extends RecipeSerializer<?>> serializer) {
        this.mode = Objects.requireNonNull(mode, "mode");
        this.container = Objects.requireNonNull(container, "container");
        this.containerCount = Math.max(0, containerCount);
        this.additive = Objects.requireNonNull(additive, "additive");
        this.additiveCount = Math.max(0, additiveCount);
        this.primaryFluid = Objects.requireNonNull(primaryFluid, "primaryFluid").copy();
        this.secondaryFluid = Objects.requireNonNull(secondaryFluid, "secondaryFluid").copy();
        this.resultItem = Objects.requireNonNull(resultItem, "resultItem").copy();
        this.resultFluid = Objects.requireNonNull(resultFluid, "resultFluid").copy();
        this.returnedContainer = Objects.requireNonNull(returnedContainer, "returnedContainer").copy();
        this.processingTicks = Math.max(1, processingTicks);
        this.energyPerTickMeu = Math.max(1L, energyPerTickMeu);
        this.totalEnergyMeu = Math.max(1L, totalEnergyMeu);
        this.type = Objects.requireNonNull(type, "type");
        this.serializer = Objects.requireNonNull(serializer, "serializer");
    }

    @Override public boolean matches(CannerRecipeInput input, Level level) {
        return matchesItem(container, containerCount, input.container())
                && matchesItem(additive, additiveCount, input.additive())
                && matchesFluid(primaryFluid, input.primaryFluid())
                && matchesFluid(secondaryFluid, input.secondaryFluid());
    }
    private static boolean matchesItem(Ingredient ingredient, int count, ItemStack stack) {
        return count == 0 ? stack.isEmpty() : stack.getCount() >= count && ingredient.test(stack);
    }
    private static boolean matchesFluid(FluidStack expected, FluidStack actual) {
        return expected.isEmpty() ? actual.isEmpty()
                : !actual.isEmpty() && FluidStack.isSameFluidSameComponents(expected, actual)
                && actual.getAmount() >= expected.getAmount();
    }
    @Override public ItemStack assemble(CannerRecipeInput input, HolderLookup.Provider registries) { return resultItem.copy(); }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return resultItem.copy(); }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }

    public Mode mode() { return mode; }
    public boolean acceptsContainer(ItemStack stack) {
        return containerCount > 0 && !stack.isEmpty() && ingredientMatches(container, stack);
    }
    public boolean acceptsAdditive(ItemStack stack) {
        return additiveCount > 0 && !stack.isEmpty() && ingredientMatches(additive, stack);
    }
    private static boolean ingredientMatches(Ingredient ingredient, ItemStack stack) {
        return ingredient.test(stack);
    }
    public Ingredient container() { return container; }
    public int containerCount() { return containerCount; }
    public Ingredient additive() { return additive; }
    public int additiveCount() { return additiveCount; }
    public FluidStack primaryFluid() { return primaryFluid.copy(); }
    public FluidStack secondaryFluid() { return secondaryFluid.copy(); }
    public ItemStack resultItem() { return resultItem.copy(); }
    public FluidStack resultFluid() { return resultFluid.copy(); }
    public ItemStack returnedContainer() { return returnedContainer.copy(); }
    public int processingTicks() { return processingTicks; }
    public long energyPerTickMeu() { return energyPerTickMeu; }
    public long totalEnergyMeu() { return totalEnergyMeu; }
}
