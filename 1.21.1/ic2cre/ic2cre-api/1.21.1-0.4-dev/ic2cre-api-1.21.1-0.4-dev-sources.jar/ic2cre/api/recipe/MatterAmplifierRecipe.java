package ic2cre.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.Level;

import java.util.function.Supplier;
import java.util.Objects;

/** 物质制造机增幅物品的公开原生配方模型。 / Public native recipe model for Matter Fabricator amplifiers. */
public final class MatterAmplifierRecipe implements Recipe<SingleRecipeInput> {
    private final Ingredient ingredient;
    private final int inputCount;
    private final long amplification;
    private final Supplier<? extends RecipeType<?>> type;
    private final Supplier<? extends RecipeSerializer<?>> serializer;

    public MatterAmplifierRecipe(Ingredient ingredient, int inputCount, long amplification,
                                 Supplier<? extends RecipeType<?>> type,
                                 Supplier<? extends RecipeSerializer<?>> serializer) {
        this.ingredient = Objects.requireNonNull(ingredient, "ingredient");
        this.inputCount = Math.max(1, inputCount);
        this.amplification = Math.max(1L, amplification);
        this.type = Objects.requireNonNull(type, "type");
        this.serializer = Objects.requireNonNull(serializer, "serializer");
    }

    @Override public boolean matches(SingleRecipeInput input, Level level) {
        return input.item().getCount() >= inputCount && ingredient.test(input.item());
    }
    @Override public ItemStack assemble(SingleRecipeInput input, HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }

    public Ingredient ingredient() { return ingredient; }
    public int inputCount() { return inputCount; }
    public long amplification() { return amplification; }
}
