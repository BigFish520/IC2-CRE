package ic2cre.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.function.Supplier;
import java.util.Objects;

/** 打开废料盒时使用的公开加权掉落项。 / Public weighted drop entry used when opening a scrap box. */
public final class ScrapboxDropRecipe implements Recipe<RecipeInput> {
    private final ItemStack result;
    private final float weight;
    private final Supplier<? extends RecipeType<?>> type;
    private final Supplier<? extends RecipeSerializer<?>> serializer;

    public ScrapboxDropRecipe(ItemStack result, float weight,
                              Supplier<? extends RecipeType<?>> type,
                              Supplier<? extends RecipeSerializer<?>> serializer) {
        Objects.requireNonNull(result, "result");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(serializer, "serializer");
        if (result.isEmpty() || !Float.isFinite(weight) || weight <= 0) throw new IllegalArgumentException("Invalid scrapbox drop");
        this.result = result.copy();
        this.weight = weight;
        this.type = type;
        this.serializer = serializer;
    }

    @Override public boolean matches(RecipeInput input, Level level) { return false; }
    @Override public ItemStack assemble(RecipeInput input, HolderLookup.Provider registries) { return result.copy(); }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return result.copy(); }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }

    public ItemStack result() { return result.copy(); }
    public float weight() { return weight; }
}
