package ic2cre.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;

import java.util.function.Supplier;
import java.util.Objects;

/** 液体热交换的公开原生配方模型。 / Public native recipe model for liquid heat exchange. */
public record LiquidHeatExchangeRecipe(ResourceLocation input, ResourceLocation output, int huPerMb,
                                       Supplier<? extends RecipeType<?>> type,
                                       Supplier<? extends RecipeSerializer<?>> serializer) implements Recipe<RecipeInput> {
    public LiquidHeatExchangeRecipe {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(output, "output");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(serializer, "serializer");
        if (huPerMb <= 0) throw new IllegalArgumentException("huPerMb must be positive");
    }
    public boolean matches(Fluid fluid) { return fluid != null && input.equals(BuiltInRegistries.FLUID.getKey(fluid)); }
    public Fluid outputFluid() { return BuiltInRegistries.FLUID.get(output); }
    @Override public boolean matches(RecipeInput input, Level level) { return false; }
    @Override public ItemStack assemble(RecipeInput input, HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }
}
