package ic2cre.api.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;

import java.util.function.Supplier;
import java.util.Objects;

/** 基于流体标签的公共燃料配方模型。 / Public fuel recipe model based on fluid tags. */
public record FluidFuelRecipe(ResourceLocation fluidTag, int amount, double value,
                              Supplier<? extends RecipeType<?>> type,
                              Supplier<? extends RecipeSerializer<?>> serializer) implements Recipe<RecipeInput> {
    public FluidFuelRecipe {
        Objects.requireNonNull(fluidTag, "fluidTag");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(serializer, "serializer");
        if (amount <= 0 || !Double.isFinite(value) || value <= 0) throw new IllegalArgumentException("Invalid fluid fuel");
    }
    public boolean matches(Fluid fluid) {
        return fluid != null && BuiltInRegistries.FLUID.wrapAsHolder(fluid)
                .is(TagKey.create(Registries.FLUID, fluidTag));
    }
    @Override public boolean matches(RecipeInput input, Level level) { return false; }
    @Override public ItemStack assemble(RecipeInput input, HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }
}
