package ic2cre.api.recipe;

import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * 相邻模式存储接口，供复制机和扫描机按职责访问模板。 / Adjacent pattern storage contract used by replicators and scanners.
 */
public interface IPatternStorage {

    boolean addPattern(ItemStack pattern);

    /** 返回调用方不可修改的模式快照。 / Returns a caller-immutable pattern snapshot. */
    List<ItemStack> getPatterns();
}
