package ic2cre.api.recipe;

import ic2cre.api.gas.Gas;
import ic2cre.api.gas.GasRegistry;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;

import java.util.function.Supplier;
import java.util.Objects;

/** 流体发酵为气体的公开原生配方模型。 / Public native recipe model for fluid-to-gas fermentation. */
public record FermenterRecipe(ResourceLocation input, int inputAmount, int heat,
                              ResourceLocation outputGas, int outputAmount,
                              Supplier<? extends RecipeType<?>> type,
                              Supplier<? extends RecipeSerializer<?>> serializer) implements Recipe<RecipeInput> {
    public FermenterRecipe {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(outputGas, "outputGas");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(serializer, "serializer");
        if (inputAmount <= 0 || heat <= 0 || outputAmount <= 0) throw new IllegalArgumentException("Invalid fermenter recipe");
    }
    public boolean matches(Fluid fluid) { return fluid != null && input.equals(BuiltInRegistries.FLUID.getKey(fluid)); }
    public Gas output() { return GasRegistry.get(outputGas); }
    @Override public boolean matches(RecipeInput input, Level level) { return false; }
    @Override public ItemStack assemble(RecipeInput input, HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }
}
