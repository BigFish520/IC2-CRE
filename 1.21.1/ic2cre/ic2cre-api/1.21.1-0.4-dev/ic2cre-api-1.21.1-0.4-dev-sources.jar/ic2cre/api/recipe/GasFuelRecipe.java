package ic2cre.api.recipe;

import ic2cre.api.gas.Gas;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.function.Supplier;
import java.util.Objects;

/** IC2 气体燃料的公开原生配方模型。 / Public native recipe model for IC2 gas fuels. */
public record GasFuelRecipe(ResourceLocation gas, int amount, double power,
                            Supplier<? extends RecipeType<?>> type,
                            Supplier<? extends RecipeSerializer<?>> serializer) implements Recipe<RecipeInput> {
    public GasFuelRecipe {
        Objects.requireNonNull(gas, "gas");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(serializer, "serializer");
        if (amount <= 0 || !Double.isFinite(power) || power <= 0) throw new IllegalArgumentException("Invalid gas fuel");
    }
    public boolean matches(Gas candidate) { return candidate != null && gas.equals(candidate.getId()); }
    @Override public boolean matches(RecipeInput input, Level level) { return false; }
    @Override public ItemStack assemble(RecipeInput input, HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public boolean canCraftInDimensions(int width, int height) { return true; }
    @Override public ItemStack getResultItem(HolderLookup.Provider registries) { return ItemStack.EMPTY; }
    @Override public RecipeSerializer<?> getSerializer() { return serializer.get(); }
    @Override public RecipeType<?> getType() { return type.get(); }
}
