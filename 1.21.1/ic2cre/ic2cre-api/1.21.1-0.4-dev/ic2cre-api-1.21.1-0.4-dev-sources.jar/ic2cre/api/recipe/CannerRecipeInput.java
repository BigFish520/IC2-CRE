package ic2cre.api.recipe;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;
import net.neoforged.neoforge.fluids.FluidStack;

/** 原生装罐配方匹配所使用的完整输入快照。 / Complete input snapshot used to match a native canner recipe. */
public record CannerRecipeInput(ItemStack container, ItemStack additive,
                                FluidStack primaryFluid, FluidStack secondaryFluid) implements RecipeInput {
    public CannerRecipeInput {
        container = container == null ? ItemStack.EMPTY : container.copy();
        additive = additive == null ? ItemStack.EMPTY : additive.copy();
        primaryFluid = primaryFluid == null ? FluidStack.EMPTY : primaryFluid.copy();
        secondaryFluid = secondaryFluid == null ? FluidStack.EMPTY : secondaryFluid.copy();
    }
    @Override public ItemStack getItem(int index) {
        return switch (index) { case 0 -> container; case 1 -> additive; default -> throw new IndexOutOfBoundsException(index); };
    }
    @Override public int size() { return 2; }
}
