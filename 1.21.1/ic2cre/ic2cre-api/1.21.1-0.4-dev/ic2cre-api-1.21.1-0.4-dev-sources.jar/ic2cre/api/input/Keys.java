package ic2cre.api.input;

import java.util.Objects;

/** 只读按键服务；状态由主体网络协议更新。 / Read-only key service; the core network protocol owns state updates. */
public final class Keys {
    private static volatile IKeyboard keyboard;
    private Keys() {}
    public static IKeyboard getKeyboard() {
        return Objects.requireNonNull(keyboard, "IC2CRE keyboard service is not bound");
    }
    public static synchronized void bind(IKeyboard implementation) {
        Objects.requireNonNull(implementation, "implementation");
        if (keyboard != null && keyboard != implementation) throw new IllegalStateException("Keyboard service already bound");
        keyboard = implementation;
    }
}
