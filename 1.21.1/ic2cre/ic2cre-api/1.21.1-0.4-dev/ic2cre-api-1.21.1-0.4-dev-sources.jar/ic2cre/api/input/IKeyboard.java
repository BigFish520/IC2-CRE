package ic2cre.api.input;

import net.minecraft.world.entity.player.Player;

/** IC2 物品与装备共享的只读功能键状态。 / Read-only functional-key state shared by IC2 items and equipment. */
public interface IKeyboard {
    boolean isAltKeyDown(Player player);
    boolean isBoostKeyDown(Player player);
    boolean isForwardKeyDown(Player player);
    boolean isJumpKeyDown(Player player);
    boolean isModeSwitchKeyDown(Player player);
    boolean isSideInventoryKeyDown(Player player);
    boolean isHudModeKeyDown(Player player);
    boolean isSneakKeyDown(Player player);
}
