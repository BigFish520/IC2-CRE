package ic2cre.api.engine.wake;

import ic2cre.api.engine.FlowType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/** 仅保存几何和倍率的尾流切片。 / Wake slice storing only geometry and its speed multiplier. */
public record WakeSlice(FlowType flowType, BlockPos origin, Direction direction,
                        int radius, int length, double speedMultiplier) {
    public WakeSlice {
        if (flowType == null || origin == null || direction == null) {
            throw new IllegalArgumentException("wake fields cannot be null");
        }
        if (radius < 0 || radius > 128 || length < 0 || length > 1024)
            throw new IllegalArgumentException("wake dimensions exceed bounds");
        if (!Double.isFinite(speedMultiplier) || speedMultiplier < 0.0D || speedMultiplier > 1.0D)
            throw new IllegalArgumentException("wake multiplier must be between zero and one");
        origin = origin.immutable();
    }
}
