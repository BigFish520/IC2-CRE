package ic2cre.api.engine;

import java.util.Objects;
import java.util.function.Function;
import net.minecraft.server.level.ServerLevel;

/** 仅暴露环境查询契约；服务实例和生命周期由主体持有。 / Exposes only the environment contract; the core owns services and lifecycle. */
public final class EnvironmentPhysicsEngine {
    private static volatile Function<ServerLevel, EnvironmentPhysicsApi> provider;
    private EnvironmentPhysicsEngine() {}

    public static EnvironmentPhysicsApi get(ServerLevel level) {
        Objects.requireNonNull(level, "level");
        return Objects.requireNonNull(provider, "IC2CRE environment service is not bound").apply(level);
    }

    public static synchronized void bind(Function<ServerLevel, EnvironmentPhysicsApi> implementation) {
        Objects.requireNonNull(implementation, "implementation");
        if (provider != null && provider != implementation) throw new IllegalStateException("Environment service already bound");
        provider = implementation;
    }
}
