package ic2cre.api.engine;

import net.minecraft.world.phys.Vec3;
import java.util.Objects;

/** 服务端生成的风/水开放流场不可变快照。 / Immutable server-generated snapshot of an open wind or water flow. */
public record FlowSample(
        FlowType type,
        boolean valid,
        double speedMps,
        Vec3 direction,
        double density,
        double depth,
        double turbulence,
        double wakeMultiplier,
        FlowInvalidReason invalidReason,
        long sampleTick) {

    public FlowSample {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(direction, "direction");
        Objects.requireNonNull(invalidReason, "invalidReason");
        if (!Double.isFinite(speedMps) || !Double.isFinite(density) || !Double.isFinite(depth)
                || !Double.isFinite(turbulence) || !Double.isFinite(wakeMultiplier)
                || !Double.isFinite(direction.x) || !Double.isFinite(direction.y) || !Double.isFinite(direction.z)) {
            throw new IllegalArgumentException("flow sample values must be finite");
        }
        if (valid == (invalidReason != FlowInvalidReason.NONE))
            throw new IllegalArgumentException("validity and invalidReason disagree");
        if (sampleTick < 0L) throw new IllegalArgumentException("sampleTick must not be negative");
    }

    public static FlowSample invalid(FlowType type, FlowInvalidReason reason, long tick) {
        return new FlowSample(type, false, 0.0D, Vec3.ZERO, 0.0D, 0.0D,
                0.0D, 1.0D, reason, tick);
    }
}
