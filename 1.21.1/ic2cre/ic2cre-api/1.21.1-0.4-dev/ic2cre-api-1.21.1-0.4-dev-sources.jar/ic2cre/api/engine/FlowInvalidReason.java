package ic2cre.api.engine;

/** 环境采样不可用的明确原因。 / Explicit reason why an environment sample is unavailable. */
public enum FlowInvalidReason {
    NONE,
    CLIENT_LEVEL,
    UNLOADED_POSITION,
    BUDGET_EXHAUSTED,
    UNSUPPORTED_FLOW,
    NO_WATER,
    INVALID_BIOME,
    INVALID_HEIGHT,
    NO_STEAM_STATE,
    OPEN_SYSTEM
}
