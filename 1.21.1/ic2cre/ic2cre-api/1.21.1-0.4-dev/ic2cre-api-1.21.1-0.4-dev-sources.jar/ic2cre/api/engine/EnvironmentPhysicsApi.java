package ic2cre.api.engine;

import ic2cre.api.engine.wake.WakeSlice;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/** 机器和其他系统访问环境物理引擎的稳定契约。 / Stable environment-physics contract for machines and other systems. */
public interface EnvironmentPhysicsApi {
    FlowSample queryFlow(FlowQueryContext context);

    FlowInterestHandle acquireInterest(FlowInterest interest);

    long registerWake(WakeSlice slice);

    void removeWake(long wakeId);

    void registerRotor(BlockPos position, Direction facing, int radius);

    boolean isRotorConflicted(BlockPos position);

    void invalidate(BlockPos position);

    void publishFlowSnapshot(BlockPos position, FlowSample sample);
}
