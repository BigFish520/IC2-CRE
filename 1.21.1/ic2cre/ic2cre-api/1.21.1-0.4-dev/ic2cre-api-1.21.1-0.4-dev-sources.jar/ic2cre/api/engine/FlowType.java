package ic2cre.api.engine;

/** 环境引擎支持的动力学类型。 / Flow domains supported by the environment engine. */
public enum FlowType {
    ATMOSPHERE,
    HYDRODYNAMIC
}
