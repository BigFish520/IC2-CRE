package ic2cre.api.engine;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import java.util.Objects;

/** 动力机器查询环境流场的不可变上下文。 / Immutable context for a kinetic machine's flow query. */
public record FlowQueryContext(
        BlockPos position,
        Direction facing,
        int rotorRadius,
        int rotorLength,
        FlowType flowType,
        boolean includeWake) {

    public FlowQueryContext {
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(facing, "facing");
        Objects.requireNonNull(flowType, "flowType");
        if (rotorRadius < 0 || rotorLength < 0) throw new IllegalArgumentException("rotor dimensions cannot be negative");
        position = position.immutable();
    }

    public static FlowQueryContext point(BlockPos position, FlowType type) {
        return new FlowQueryContext(position, Direction.NORTH, 0, 0, type, false);
    }

    public boolean includesWake() {
        return includeWake;
    }
}
