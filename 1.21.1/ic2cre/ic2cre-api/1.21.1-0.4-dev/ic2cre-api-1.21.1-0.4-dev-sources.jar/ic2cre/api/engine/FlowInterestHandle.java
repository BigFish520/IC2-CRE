package ic2cre.api.engine;

/** 兴趣注册的生命周期句柄；关闭后不再请求区域唤醒。 / Lifecycle handle that stops requesting an active region after close. */
@FunctionalInterface
public interface FlowInterestHandle extends AutoCloseable {
    @Override
    void close();
}
