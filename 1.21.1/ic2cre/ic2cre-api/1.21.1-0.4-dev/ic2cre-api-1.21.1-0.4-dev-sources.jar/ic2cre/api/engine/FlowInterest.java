package ic2cre.api.engine;

import net.minecraft.core.BlockPos;
import java.util.Objects;

/** 环境引擎调度活跃区域的轻量兴趣声明。 / Lightweight active-region interest used by the environment scheduler. */
public record FlowInterest(BlockPos center, FlowType type, int radius) {
    public FlowInterest {
        Objects.requireNonNull(center, "center");
        Objects.requireNonNull(type, "type");
        if (radius < 0) throw new IllegalArgumentException("radius cannot be negative");
        center = center.immutable();
    }
}
