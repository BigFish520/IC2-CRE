package ic2cre.api.tool;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import org.jetbrains.annotations.Nullable;

/** 定义方块的扳手旋转与拆卸许可。 / Defines wrench rotation and removal permission for a block. */
public interface IWrenchable {
    default @Nullable DirectionProperty getWrenchFacingProperty(BlockState state) {
        if (state.hasProperty(BlockStateProperties.FACING)) return BlockStateProperties.FACING;
        if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) return BlockStateProperties.HORIZONTAL_FACING;
        return null;
    }

    default @Nullable Direction getWrenchFacing(BlockState state) {
        DirectionProperty property = getWrenchFacingProperty(state);
        return property == null ? null : state.getValue(property);
    }

    default boolean canSetWrenchFacing(Level level, BlockPos pos, BlockState state,
                                       Direction facing, Player player) {
        DirectionProperty property = getWrenchFacingProperty(state);
        return property != null && property.getPossibleValues().contains(facing);
    }

    default boolean setWrenchFacing(Level level, BlockPos pos, BlockState state,
                                    Direction facing, Player player) {
        if (level.isClientSide) return false;
        DirectionProperty property = getWrenchFacingProperty(state);
        if (property == null || !canSetWrenchFacing(level, pos, state, facing, player)) return false;
        return level.setBlock(pos, state.setValue(property, facing), Block.UPDATE_ALL);
    }

    default boolean canRemoveWithWrench(Level level, BlockPos pos, BlockState state, Player player) {
        return true;
    }

    /**
     * 返回 null 沿用正常破坏掉落；非 null 列表完整接管本次掉落（包括需要保留的库存），空列表表示无掉落。
     * / Null preserves normal destruction drops; a non-null list owns all drops, including retained inventory; an empty list drops nothing.
     */
    default @Nullable java.util.List<net.minecraft.world.item.ItemStack> getWrenchDrops(
            Level level, BlockPos pos, BlockState state,
            @Nullable net.minecraft.world.level.block.entity.BlockEntity blockEntity,
            Player player, net.minecraft.world.item.ItemStack tool) {
        return null;
    }
}
