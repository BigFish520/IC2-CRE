package ic2cre.api.heat;

import net.minecraft.core.Direction;

/** 使用 HU 的公共热量输入输出接口。 / Public heat input/output contract using HU. */
public interface HeatHandler {
    int drawHeat(Direction fromSide, int maxAmount);
    /** 返回指定方向本 tick 尚可抽取的 HU，不改变热源状态。 / Returns HU still available from this side this tick without mutating the source. */
    default int getAvailableHeat(Direction fromSide) { return getHeat(); }
    int addHeat(int amount);
    int getHeat();
    int getMaxHeat();
    boolean isSource();
}
