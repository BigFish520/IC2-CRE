package ic2cre.api.heat;

import ic2cre.api.Ic2CreAPI;
import net.minecraft.core.Direction;
import net.neoforged.neoforge.capabilities.BlockCapability;

/** IC2:CRE 热源和热消费者的 NeoForge 能力。 / NeoForge capability for IC2:CRE heat sources and consumers. */
public final class HeatCapabilities {
    private HeatCapabilities() {}
    public static final BlockCapability<HeatHandler, Direction> HEAT_HANDLER_BLOCK =
            BlockCapability.createSided(Ic2CreAPI.resource("heat_handler"), HeatHandler.class);
}
